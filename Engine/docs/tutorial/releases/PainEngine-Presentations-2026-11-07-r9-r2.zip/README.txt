PainEngine — презентации от 7 ноября 2026

Tutorial: расширенный туториал, 71 слайд. Changes: обзор изменений, 25 слайдов.
Готовые PPTX и PDF находятся в Presentations. PPTX редактируется в PowerPoint; PDF содержит растровые слайды.
Sources содержит content.json, changes.json, build.mjs, assets и examples.
Полные новые C++ примеры: Sources/examples/PresentationSources; порядок использования описан в README.txt этой папки.
Для пересборки перенесите Sources в Engine/docs/tutorial репозитория PainEngine. Генератор использует Node.js, Python и библиотеки навыка Presentations; переменные RUNTIME_NODE_MODULES, RUNTIME_PYTHON, PRESENTATIONS_SKILL. Команды: node build.mjs; для второй презентации задайте TUTORIAL_CONTENT=changes.json и выполните node build.mjs.
Это обновление презентаций. Архив движка PainEngine-2026.11.07.6-learning-win64.zip не изменён.
Снимки Qt получены штатным тестовым запуском редактора; D3D-сцены — из сохранённых тестовых захватов. Код показан из реальных файлов. Каталоги — локальное представление существующих папок.
Метрики взяты из сохранённых отчётов версии 2026.11.07.6; FPS и время GPU не измерялись.
