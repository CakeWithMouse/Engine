#include "TutorialHud.h"
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <stdexcept>

TutorialHud::TutorialHud(const std::filesystem::path& markupFile) {
    FontAtlasSettings font;
    font.Face = L"Consolas";
    font.PixelHeight = 18;
    SetFont(font);
    if (!LoadMarkup(markupFile.generic_u8string()))
        throw std::runtime_error("Cannot load tutorial HUD: " + markupFile.generic_u8string());
    BindElements();
}

void TutorialHud::BindElements() {
    revision_ = GetMarkupRevision();
    label_ = Find<UILabel>("clicks");
    bar_ = Find<UIBar>("load");
    if (auto* button = Find<UIButton>("add"))
        button->OnClick = [this] { ++clicks_; };
}

void TutorialHud::Tick(float deltaTime) {
    UIComponent::Tick(deltaTime); // Polls markup and routes the mouse.
    if (GetMarkupRevision() != revision_) BindElements();
    // After reload, only the newly found pointers may be dereferenced.
    if (label_) label_->SetText("Нажатий: " + std::to_string(clicks_));
    if (bar_) bar_->Fill = static_cast<float>(clicks_ % 11) / 10.0f;
}

void AttachTutorialHud(Game& game, const std::filesystem::path& markupFile) {
    auto hud = std::make_unique<TutorialHud>(markupFile);
    // UIComponent's constructor selects Shaders/UI.hlsl.
    const auto result = game.RegisterComponent("TutorialHud", hud.get());
    if (result != RegisterResult::Ok)
        throw std::runtime_error("Cannot register TutorialHud");
    hud.release();
}
