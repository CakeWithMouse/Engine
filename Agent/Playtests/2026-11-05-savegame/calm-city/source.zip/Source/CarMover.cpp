#include "CarMover.h"

#include <algorithm>
#include <Engine/SaveGame/SaveArchive.h>
#include <Engine/SaveGame/SaveGame.h>
#include <Engine/InputDevice/Keys.h>

CarMover::CarMover()
{
    SetColor({0.92f, 0.23f, 0.12f, 1.0f});
}

void CarMover::BeginPlay()
{
    CubeComponent::BeginPlay();
    auto* game = GetGame();
    if (!game) return;
    auto& input = game->GetInput();
    input.Bind({"CalmCity.Save", Input::Context::Game, {Keys::F6}});
    input.Bind({"CalmCity.Load", Input::Context::Game, {Keys::F9}});
    saveConnection_ = input.Subscribe(inputScope_, Input::Context::Game,
        "CalmCity.Save", Input::Phase::Pressed,
        [game](const Input::Event&) { game->Saves().RequestSave("manual-1"); });
    loadConnection_ = input.Subscribe(inputScope_, Input::Context::Game,
        "CalmCity.Load", Input::Phase::Pressed,
        [game](const Input::Event&) { game->Saves().RequestLoad("manual-1"); });
}

void CarMover::Tick(float deltaTime)
{
    CubeComponent::Tick(deltaTime);
    if (!moving || deltaTime <= 0.0f)
        return;

    auto position = GetLocalPosition();
    const float limit = 5.6f;
    position.x += (goingRight ? 1.0f : -1.0f) * speed * deltaTime;
    if (position.x >= limit) {
        position.x = limit;
        goingRight = false;
    } else if (position.x <= -limit) {
        position.x = -limit;
        goingRight = true;
    }
    SetPosition(position);
}

void CarMover::SerializeSaveGame(SaveArchive& archive)
{
    CubeComponent::SerializeSaveGame(archive);
    archive.Section("CalmCar", [&](SaveArchive& state) {
        state.Version(1);
        state.Field("speed", speed);
        state.Field("moving", moving);
        state.Field("goingRight", goingRight);
    });
}
