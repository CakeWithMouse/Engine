#include "ProjectGame.h"
#include "CarMover.h"
#include <Engine/Components/Character.h>
#include <Engine/Components/Light/DirectionalLightComponent.h>
#include <stdexcept>
#include <filesystem>
#include <Engine/SaveGame/SaveGame.h>
#include <cmath>
#include <cstdlib>
#include <fstream>

namespace {
CarMover* FindTestCar(Scene& scene)
{
    for (const auto& entry : scene.GetComponents())
        if (auto* car = dynamic_cast<CarMover*>(entry.second.get())) return car;
    return nullptr;
}

void SaveTestLog(const std::string& line)
{
    const auto root = std::filesystem::absolute(std::filesystem::path(__FILE__))
        .parent_path().parent_path() / "SaveData";
    std::filesystem::create_directories(root);
    std::ofstream log(root / "SaveGameSelfTest.log", std::ios::app);
    log << line << '\n';
    if (!log) throw std::runtime_error("Cannot write SaveGameSelfTest.log");
}
}

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    const auto saveRoot = std::filesystem::absolute(std::filesystem::path(__FILE__))
        .parent_path().parent_path() / "SaveData";
    Saves().Configure("calm-city", saveRoot);
    if (const char* phase = std::getenv("CALM_SAVE_TEST")) {
        if (std::string(phase) == "save") saveTestMode_ = 1;
        else if (std::string(phase) == "load") saveTestMode_ = 2;
        else throw std::runtime_error("CALM_SAVE_TEST must be 'save' or 'load'");
        std::filesystem::create_directories(saveRoot);
        if (saveTestMode_ == 1) {
            std::ofstream log(saveRoot / "SaveGameSelfTest.log", std::ios::trunc);
            if (!log) throw std::runtime_error("Cannot initialize SaveGameSelfTest.log");
        }
    }
    // One full turn in four real seconds; the diagnostic scenario advances explicitly.
    SetSimulationTimeScale(saveTestMode_ ? 0.0f : 1.0f);
    auto& scene = GetScene();
    // An overview camera and a sun make the existing city readable at first Play.
    std::unique_ptr<GameComponent> camera = std::make_unique<SceneCamera>();
    camera->SetPosition({14.0f, 12.0f, 18.0f});
    camera->SetRotation({-28.0f, 38.0f, 0.0f});
    const auto cameraResult = scene.AddComponent("City overview", camera);
    if (cameraResult.result != SceneResult::Ok) throw std::runtime_error("Cannot create city camera");
    auto player = std::make_unique<Character>();
    player->SetPlayerControlled(true);
    player->standardControl = false;
    player->camera = cameraResult.id;
    std::unique_ptr<GameComponent> playerComponent = std::move(player);
    if (scene.AddComponent("City viewer", playerComponent).result != SceneResult::Ok)
        throw std::runtime_error("Cannot create city viewer");
    bool hasSun = false;
    for (const auto& entry : scene.GetComponents())
        if (dynamic_cast<DirectionalLightComponent*>(entry.second.get())) hasSun = true;
    if (!hasSun) {
        std::unique_ptr<GameComponent> sun = std::make_unique<DirectionalLightComponent>();
        sun->SetRotation({-50.0f, -30.0f, 0.0f});
        if (scene.AddComponent("City sun", sun, "Light.Directional").result != SceneResult::Ok)
            throw std::runtime_error("Cannot create city sun");
    }
    // A saved CarMover already supplies the example after loading/Play.
    bool hasCar = false;
    for (const auto& entry : scene.GetComponents())
        if (dynamic_cast<CarMover*>(entry.second.get())) hasCar = true;
    if (!hasCar) {
        std::unique_ptr<GameComponent> cube = std::make_unique<CarMover>();
        cube->SetPosition({-5.6f, 0.55f, 0.0f});
        cube->SetScale({1.35f, 0.35f, 0.72f});
        std::string name = "Car mover";
        for (unsigned suffix = 2; scene.FindComponentByName(name); ++suffix)
            name = "Car mover " + std::to_string(suffix);
        const auto added = scene.AddComponent(name, cube, "CalmCity.CarMover");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the starter car");
    }
}

void ProjectGame::PreUpdate(float deltaTime)
{
    Game::PreUpdate(deltaTime);
    if (!saveTestMode_ || saveTestStep_ >= 7) return;
    if (saveTestStep_ >= 3) {
        if (saveTestStep_ < 6) {
            ++saveTestStep_;
            return;
        }
        const auto root = std::filesystem::absolute(std::filesystem::path(__FILE__)).parent_path().parent_path() / "SaveData";
        RequestFrameDump((root / (saveTestMode_ == 1 ? "save-load-same-process.bmp" : "save-load-new-process.bmp")).u8string());
        saveTestStep_ = 7;
        return;
    }
    auto* car = FindTestCar(GetScene());
    if (!car) throw std::runtime_error("SaveGame test cannot find CalmCar");
    if (saveTestMode_ == 1) {
        if (saveTestStep_ == 0) {
            car->Tick(10.0f); // Reach the right endpoint; route direction becomes left.
            saveTestX_ = car->GetLocalPosition().x;
            if (std::abs(saveTestX_ - 5.6f) > 0.001f)
                throw std::runtime_error("SaveGame test could not prepare the leftbound route");
            const auto request = Saves().RequestSave("manual-1");
            if (request.status != SaveGameResult::Status::Accepted)
                throw std::runtime_error("SaveGame test save request was not accepted: " + request.message);
            SaveTestLog("process=save request=accepted positionX=" + std::to_string(saveTestX_) + " route=left");
            saveTestStep_ = 1;
        } else if (saveTestStep_ == 1) {
            if (Saves().LastResult().status != SaveGameResult::Status::Saved)
                throw std::runtime_error("SaveGame test did not finish saving: " + Saves().LastResult().message);
            car->Tick(1.0f);
            const float advancedX = car->GetLocalPosition().x;
            if (!(advancedX < saveTestX_)) throw std::runtime_error("Car did not advance after save");
            const auto request = Saves().RequestLoad("manual-1");
            if (request.status != SaveGameResult::Status::Accepted)
                throw std::runtime_error("SaveGame test load request was not accepted: " + request.message);
            SaveTestLog("process=save result=saved advancedX=" + std::to_string(advancedX) + " request=load-accepted");
            saveTestStep_ = 2;
        } else {
            if (Saves().LastResult().status != SaveGameResult::Status::Loaded)
                throw std::runtime_error("SaveGame test did not finish loading: " + Saves().LastResult().message);
            car = FindTestCar(GetScene());
            if (!car) throw std::runtime_error("Loaded scene has no CalmCar");
            const float loadedX = car->GetLocalPosition().x;
            if (std::abs(loadedX - saveTestX_) > 0.001f)
                throw std::runtime_error("Loaded CalmCar position differs from the saved position");
            car->Tick(0.1f);
            const float continuedX = car->GetLocalPosition().x;
            if (!(continuedX < loadedX)) throw std::runtime_error("Loaded CalmCar did not continue its saved leftbound route");
            SaveTestLog("process=save result=loaded loadedX=" + std::to_string(loadedX) + " continuedX=" + std::to_string(continuedX) + " PASS");
            saveTestStep_ = 3;
        }
    } else {
        if (saveTestStep_ == 0) {
            const auto request = Saves().RequestLoad("manual-1");
            if (request.status != SaveGameResult::Status::Accepted)
                throw std::runtime_error("Cross-process load request was not accepted: " + request.message);
            SaveTestLog("process=new request=load-accepted");
            saveTestStep_ = 1;
        } else {
            if (Saves().LastResult().status != SaveGameResult::Status::Loaded)
                throw std::runtime_error("Cross-process load did not finish: " + Saves().LastResult().message);
            car = FindTestCar(GetScene());
            if (!car) throw std::runtime_error("Cross-process loaded scene has no CalmCar");
            const float loadedX = car->GetLocalPosition().x;
            if (std::abs(loadedX - 5.6f) > 0.001f)
                throw std::runtime_error("Cross-process CalmCar position is not the saved endpoint");
            car->Tick(0.1f);
            const float continuedX = car->GetLocalPosition().x;
            if (!(continuedX < loadedX)) throw std::runtime_error("Cross-process route did not continue leftbound");
            SaveTestLog("process=new result=loaded loadedX=" + std::to_string(loadedX) + " continuedX=" + std::to_string(continuedX) + " PASS");
            saveTestStep_ = 3;
        }
    }
}
void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }
// Release playtest: preserve unsaved city edits across a rebuilt game module.
