cbuffer MaterialParams : register(b1)
{
    float4 Tint = float4(0.74f, 0.48f, 0.24f, 1.0f);
    float Gloss = 0.12f;
};

void Surface(MaterialInput i, inout MaterialOutput o)
{
    o.Albedo = Tint.rgb;
    o.SpecularWeight = Gloss;
    o.AmbientModel = 1.0f;
}
