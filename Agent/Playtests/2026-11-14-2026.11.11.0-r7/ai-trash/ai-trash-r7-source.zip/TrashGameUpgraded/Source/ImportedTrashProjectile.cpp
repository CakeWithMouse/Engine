#include "ImportedTrashProjectile.h"

#include "BucketParts.h"
#include "ProjectGame.h"

#include <Engine/Scene/Scene.h>
#include <Engine/Scene/SceneAssets.h>
#include <Engine/Scene/Trace.h>
#include <algorithm>
#include <cmath>
#include <stdexcept>

void ImportedTrashProjectile::Configure(uint64_t targetId, const glm::vec3& start, float duration, float aimOffset)
{
    targetId_ = targetId;
    start_ = start;
    duration_ = (std::max)(duration, 0.1f);
    elapsed_ = 0.0f;
    resolved_ = false;
    aimOffset_ = aimOffset;

    if (!LoadFromVfs("/Game/Models/blend-suzanne-multiple/blend-suzanne-multiple.glb"))
        throw std::runtime_error("Could not load the imported multi-material trash item");
    SetMaterialAsset("");
    const auto& slots = GetMaterialSlots();
    if (slots.size() != 2)
        throw std::runtime_error("Imported trash item needs two material slots");
    auto first = slots.begin();
    auto second = std::next(first);
    const std::string materialZero = "/Game/Models/blend-suzanne-multiple/Materials/Material_0.mat";
    const std::string materialOne = "/Game/Models/blend-suzanne-multiple/Materials/Material_1.mat";
    if (!SetMaterialSlot(first->first, materialOne) || !SetMaterialSlot(second->first, materialZero))
        throw std::runtime_error("Could not assign the imported trash item material slots");
    SetScale({0.42f, 0.42f, 0.42f});
    SetPosition(start_);
}

void ImportedTrashProjectile::Tick(float deltaTime)
{
    SkeletalMeshComponent::Tick(deltaTime);
    if (resolved_ || deltaTime <= 0.0f)
        return;

    const glm::vec3 previous = GetLocalPosition();
    elapsed_ = (std::min)(elapsed_ + deltaTime, duration_);
    const float t = elapsed_ / duration_;
    const glm::vec3 next{start_.x + aimOffset_ * t, start_.y + (0.2f - start_.y) * t + 15.0f * t * (1.0f - t),
                         start_.z + 10.2f * t};
    const glm::vec3 delta = next - previous;
    const float distance = glm::length(delta);
    if (distance > 0.0001f) {
        Trace::Ray ray{previous, delta, distance};
        Trace::Query query;
        query.geometry = Trace::Geometry::Exact;
        query.maxDistance = distance;
        auto* scene = GetScene();
        for (const auto& entry : scene->GetComponents()) {
            if (dynamic_cast<const TrashFlight*>(entry.second.get()))
                query.ignore.push_back(entry.second->GetComponentId());
        }
        const auto hit = scene->Raycast(ray, query);
        if (hit) {
            if (hit.hit->componentId == targetId_) {
                if (auto* game = dynamic_cast<ProjectGame*>(GetGame()))
                    game->RegisterHit();
            } else if (auto* game = dynamic_cast<ProjectGame*>(GetGame())) {
                const auto* hitComponent = scene->FindComponent(hit.hit->componentId);
                game->RegisterMiss(dynamic_cast<const BucketWall*>(hitComponent)
                    ? "The trash hit the bucket wall."
                    : "The trash hit an obstacle.");
            }
            resolved_ = true;
            return;
        }
    }

    SetPosition(next);
    if (t >= 1.0f) {
        resolved_ = true;
        if (auto* game = dynamic_cast<ProjectGame*>(GetGame()))
            game->RegisterMiss("The trash missed the bucket.");
    }
}

void ImportedTrashProjectile::SerializeSaveGame(SaveArchive& archive)
{
    SkeletalMeshComponent::SerializeSaveGame(archive);
    archive.Section("Trash.ImportedProjectile", [&](SaveArchive& state) {
        state.Version(1);
        state.Reference("target", targetId_);
        state.Field("start", start_);
        state.Field("elapsed", elapsed_);
        state.Field("duration", duration_);
        state.Field("aimOffset", aimOffset_);
        state.Field("resolved", resolved_);
        if (duration_ <= 0.0f || elapsed_ < 0.0f || elapsed_ > duration_)
            throw std::runtime_error("Invalid saved imported projectile state");
    });
}
