#include "BucketParts.h"
#include <Engine/Render/MeshPrimitives.h>

BucketWall::BucketWall()
{
    SetColor({0.16f, 0.42f, 0.55f, 1.0f});
}

BucketBase::BucketBase()
{
    SetPrimitive(MeshPrimitives::Cylinder());
    SetColor({0.22f, 0.68f, 0.48f, 1.0f});
}
