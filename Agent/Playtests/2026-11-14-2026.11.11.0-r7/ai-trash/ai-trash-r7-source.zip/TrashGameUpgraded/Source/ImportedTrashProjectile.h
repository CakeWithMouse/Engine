#pragma once

#include "TrashFlight.h"
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/SkeletalMeshComponent.h>
#include <Engine/SaveGame/SaveArchive.h>
#include <glm/vec3.hpp>

ENGINE_COMPONENT("Multi-material thrown item", "Trash.MultiMaterialProjectile")
class ImportedTrashProjectile final : public SkeletalMeshComponent, public TrashFlight
{
public:
    ImportedTrashProjectile() = default;
    void Configure(uint64_t targetId, const glm::vec3& start, float duration, float aimOffset);
    void Tick(float deltaTime) override;
    bool IsResolved() const override { return resolved_; }
    float GetElapsed() const override { return elapsed_; }
    uint64_t GetProjectileId() const override { return GetComponentId(); }
    glm::vec3 GetFlightPosition() const override { return GetLocalPosition(); }
    void SerializeSaveGame(SaveArchive& archive) override;

private:
    uint64_t targetId_ = 0;
    glm::vec3 start_{0.0f, 0.7f, -5.0f};
    float elapsed_ = 0.0f;
    float duration_ = 1.6f;
    bool resolved_ = false;
    float aimOffset_ = 0.0f;
};
