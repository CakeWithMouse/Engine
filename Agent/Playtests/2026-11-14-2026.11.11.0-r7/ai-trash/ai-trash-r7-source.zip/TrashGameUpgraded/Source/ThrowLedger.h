#pragma once
#include <nlohmann/json.hpp>
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/ProjectObject.h>
ENGINE_OBJECT("ThrowLedger")
class ThrowLedger
{
public:
    ThrowLedger() = default;
    uint32_t throws = 0;
    uint32_t hits = 0;
    uint32_t round = 1;
    uint32_t misses = 0;
};

template<> struct ProjectObjectAdapter<ThrowLedger>
{
    static std::unique_ptr<ThrowLedger> Create() { return std::make_unique<ThrowLedger>(); }
    static void Tick(ThrowLedger&, float) {}
    static std::string Save(const ThrowLedger& value)
    {
        return nlohmann::json{{"version",3},{"throws",value.throws},{"hits",value.hits},{"round",value.round},{"misses",value.misses}}.dump();
    }
    static void Load(ThrowLedger& value, const std::string& text)
    {
        if (text.empty()) return;
        const auto data = nlohmann::json::parse(text);
        const int version = data.at("version").get<int>();
        if (version < 1 || version > 3) throw std::runtime_error("Unsupported ThrowLedger schema");
        value.throws = data.at("throws").get<uint32_t>();
        value.hits = data.at("hits").get<uint32_t>();
        value.round = version >= 2 ? data.at("round").get<uint32_t>() : 1;
        value.misses = version >= 3 ? data.at("misses").get<uint32_t>() : 0;
    }
};
