#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/InputDevice/InputActions.h>
#include <Engine/Components/Character.h>
#include <Engine/SaveGame/SaveArchive.h>
#include <string>

ENGINE_GAME("ProjectGame")
class ProjectGame : public Game
{
public:
    void AfterInitialize() override;
    void PreUpdate(float deltaTime) override;
    void TickComponents(float deltaTime) override;
    void ThrowTrash();
    void RegisterHit();
    void RegisterMiss(const std::string& reason);
    void SerializeSaveGame(SaveArchive& archive) override;
    void OnSaveGameLoaded() override;

private:
    void UpdateHud();
    void AdjustAim(float delta);
    void SaveTestLog(const std::string& line) const;
    void BindInputActions();
    uint32_t throws_ = 0;
    uint32_t hits_ = 0;
    uint32_t misses_ = 0;
    uint32_t round_ = 1;
    float aimOffset_ = 0.0f;
    uint64_t impactBurstId_ = 0;
    float impactBurstAge_ = 0.0f;
    bool hudBound_ = false;
    bool particleTestStarted_ = false;
    int particleFramesAfterHit_ = -1;
    int particleCaptureStage_ = 0;
    int resizeCaptureStage_ = 0;
    bool renderCaptureDone_ = false;
    int saveTestMode_ = 0;
    int saveTestStep_ = 0;
    std::string saveRoot_;
    Input::Connection throwConnection_;
    Input::Connection aimLeftConnection_;
    Input::Connection aimRightConnection_;
    Input::Connection saveConnection_;
    Input::Connection loadConnection_;
    Input::Scope throwScope_;
};
