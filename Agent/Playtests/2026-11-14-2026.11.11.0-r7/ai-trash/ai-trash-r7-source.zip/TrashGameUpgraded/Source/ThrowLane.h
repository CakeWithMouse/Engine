#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>

ENGINE_COMPONENT("Throw lane", "Trash.ThrowLane")
class ThrowLane : public CubeComponent
{
public:
    ThrowLane();
};
