#include "ProjectGame.h"
#include "BucketParts.h"
#include "ImportedTrashProjectile.h"
#include "ThrowLedger.h"
#include "TrashProjectile.h"

#include <Engine/Render/MeshPrimitives.h>
#include <Engine/Scene/Scene.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/Components/Light/DirectionalLightComponent.h>
#include <Engine/Project/StandardTypes.h>
#include <Engine/SaveGame/SaveGame.h>
#include <Engine/Runtime/ModuleVfs.h>
#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>

namespace {
TrashFlight* FindMovingTrash(Scene& scene)
{
    for (const auto& entry : scene.GetComponents()) {
        auto* trash = dynamic_cast<TrashFlight*>(entry.second.get());
        if (trash && !trash->IsResolved()) return trash;
    }
    return nullptr;
}
}

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    SetSimulationTimeScale(1.0f);
    const auto saveRoot = std::filesystem::path(EngineModuleVfs::Resolve("/Game")).parent_path() / "SaveData";
    std::filesystem::create_directories(saveRoot);
    saveRoot_ = saveRoot.u8string();
    Saves().Configure("ai-trash", saveRoot);
    if (const char* test = std::getenv("TRASH_SAVE_TEST")) {
        const std::string phase(test);
        if (phase == "save") saveTestMode_ = 1;
        else if (phase == "load") saveTestMode_ = 2;
        else if (phase == "types") saveTestMode_ = 3;
        else throw std::runtime_error("TRASH_SAVE_TEST must be 'save' or 'load'");
        if (saveTestMode_ == 1 || saveTestMode_ == 3) {
            std::ofstream log(saveRoot / "RoundSaveTest.log", std::ios::trunc);
            if (!log) throw std::runtime_error("Cannot initialize RoundSaveTest.log");
        }
    }

    auto& scene = GetScene();
    if (const char* renderMode = std::getenv("TRASH_RENDER_MODE")) {
        const std::string mode(renderMode);
        if (mode == "forward") {
            GetSettings().SetRenderingType(Forward);
            SetDeferredDebugOverlay(false);
        } else if (mode == "deferred") {
            GetSettings().SetRenderingType(Deffered);
            SetDeferredDebugOverlay(false);
        } else if (mode == "gbuffer") {
            GetSettings().SetRenderingType(Deffered);
            SetDeferredDebugOverlay(true);
        } else {
            throw std::runtime_error("TRASH_RENDER_MODE must be forward, deferred or gbuffer");
        }
        SaveTestLog("backfill render-mode=" + mode + " type=" +
                    std::to_string(static_cast<int>(GetSettings().GetRenderingType())) +
                    " gbuffer-overlay=" + (mode == "gbuffer" ? "on" : "off"));
    }
    if (std::getenv("TRASH_RESIZE_TEST")) {
        OnWindowResized(640, 480, false);
        resizeCaptureStage_ = 1;
        SaveTestLog("backfill resize requested=640x480");
    }
    bool hasSun = false;
    bool hasPlayer = false;
    for (const auto& entry : scene.GetComponents()) {
        hasSun |= dynamic_cast<DirectionalLightComponent*>(entry.second.get()) != nullptr;
        if (const auto* character = dynamic_cast<Character*>(entry.second.get()))
            hasPlayer |= character->playerControlled;
    }
    if (!hasSun) {
        std::unique_ptr<GameComponent> sun = std::make_unique<DirectionalLightComponent>();
        const auto added = scene.AddComponent("Trash sun", sun, "Light.Directional");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the trash scene sun");
    }

    if (!hasPlayer) {
        auto view = std::make_unique<SceneCamera>();
        view->SetPosition({9.0f, 7.0f, -11.0f});
        view->SetRotation({-23.0f, 140.0f, 0.0f});
        view->orthographic = false;
        view->fov = 58.0f;
        view->farClip = 250.0f;
        std::unique_ptr<GameComponent> component = std::move(view);
        const auto added = scene.AddComponent("Trash view", component, "Gameplay.Camera");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the trash game camera");

        auto rig = std::make_unique<PlayerCharacter>();
        rig->SetPosition({0.0f, -100.0f, 0.0f});
        rig->SetScale({0.1f, 0.1f, 0.1f});
        rig->SetPlayerControlled(true);
        rig->standardControl = false;
        rig->camera = added.id;
        std::unique_ptr<GameComponent> player = std::move(rig);
        const auto playerAdded = scene.AddComponent("Trash camera rig", player, "Gameplay.Player");
        if (playerAdded.result != SceneResult::Ok && playerAdded.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the trash camera rig");
    }

    BindInputActions();
}

void ProjectGame::PreUpdate(float deltaTime)
{
    Game::PreUpdate(deltaTime);
    if (!hudBound_ && GetProjectHud()) {
        GetProjectHud()->BindClick("throw", [this] { ThrowTrash(); });
        hudBound_ = true;
    }
    UpdateHud();
    if (impactBurstId_ != 0) {
        impactBurstAge_ += deltaTime;
        if (impactBurstAge_ >= 0.8f) {
            GetScene().RemoveComponent(impactBurstId_);
            impactBurstId_ = 0;
        }
    }

    if (std::getenv("TRASH_PARTICLE_TEST")) {
        if (!particleTestStarted_) {
            particleTestStarted_ = true;
            ThrowTrash();
            SaveTestLog("backfill particle-test throw-started frame=1");
        }
        if (hits_ > 0 && impactBurstId_ != 0) {
            if (particleFramesAfterHit_ >= 24 && particleCaptureStage_ < 4) {
                auto* burst = dynamic_cast<ParticleSystemComponent*>(GetScene().FindComponent(impactBurstId_));
                if (!burst) throw std::runtime_error("Particle backfill cannot find impact burst");
                const int stage = particleCaptureStage_;
                if (stage == 0) { burst->SetDepthCollision(true); burst->SetSortingEnabled(true); }
                if (stage == 1) burst->SetDepthCollision(false);
                if (stage == 2) { burst->SetDepthCollision(true); burst->SetSortingEnabled(true); burst->SetSimulationRate(0.0f); }
                if (stage == 3) { burst->SetDepthCollision(true); burst->SetSortingEnabled(false); burst->SetSimulationRate(0.0f); }
                const bool collision = stage != 1;
                const bool sorting = stage != 3;
                const char* labels[] = {"collision-on-sort-on", "collision-off-sort-on",
                                        "collision-on-sort-on-frozen", "collision-on-sort-off-frozen"};
                const auto path = std::filesystem::path(saveRoot_) / (std::string("particle-") + labels[stage] + ".bmp");
                RequestFrameDump(path.u8string());
                const auto& completed = GetCompletedFrameStats();
                SaveTestLog(std::string("backfill particle-capture phase=") + labels[stage] +
                    " hit=" + std::to_string(hits_) + " throw=" + std::to_string(throws_) +
                    " ticks-after-hit=" + std::to_string(particleFramesAfterHit_) +
                    " collision=" + (collision ? "on" : "off") + " sorting=" + (sorting ? "on" : "off") +
                    " upcoming-frame=" + std::to_string(completed.frameIndex + 1) +
                    " completed-valid=" + (completed.valid ? "1" : "0"));
                ++particleCaptureStage_;
            } else if (particleCaptureStage_ == 0) {
                ++particleFramesAfterHit_;
            }
        }
    }

    const auto& completed = GetCompletedFrameStats();
    if (const char* capture = std::getenv("TRASH_MODE_CAPTURE")) {
        if (!renderCaptureDone_ && completed.valid && completed.frameIndex >= 2) {
            RequestFrameDump(capture);
            SaveTestLog("backfill render-capture mode=" +
                std::to_string(static_cast<int>(GetSettings().GetRenderingType())) +
                " completed-frame=" + std::to_string(completed.frameIndex) +
                " draw-calls=" + std::to_string(completed.counters.DrawCalls) +
                " dispatches=" + std::to_string(completed.counters.Dispatches) +
                " upcoming-frame=" + std::to_string(completed.frameIndex + 1));
            renderCaptureDone_ = true;
        }
    }

    if (resizeCaptureStage_ > 0 && resizeCaptureStage_ <= 2 && completed.valid) {
        const char* capture = std::getenv(resizeCaptureStage_ == 1 ? "TRASH_RESIZE_CAPTURE_640" : "TRASH_RESIZE_CAPTURE_320");
        if (capture) {
            RequestFrameDump(capture);
            SaveTestLog("backfill resize-capture target=" + std::string(resizeCaptureStage_ == 1 ? "640x480" : "320x240") +
                " preceding-frame=" + std::to_string(completed.frameIndex) +
                " upcoming-frame=" + std::to_string(completed.frameIndex + 1) +
                " hud-score=" + std::to_string(hits_) + "/" + std::to_string(throws_));
            if (resizeCaptureStage_ == 1) OnWindowResized(320, 240, false);
            ++resizeCaptureStage_;
        }
    }
    if (saveTestMode_ == 1) {
        if (saveTestStep_ == 0) {
            ThrowTrash();
            SaveTestLog("phase=save action=throw kind=box throws=" + std::to_string(throws_));
            saveTestStep_ = 1;
        } else if (saveTestStep_ == 1) {
            auto* moving = FindMovingTrash(GetScene());
            if (moving && moving->GetElapsed() >= 0.48f) {
                const auto request = Saves().RequestSave("round-current");
                if (request.status != SaveGameResult::Status::Accepted)
                    throw std::runtime_error("Round SaveGame request rejected: " + request.message);
                SaveTestLog("phase=save request=accepted elapsed=" + std::to_string(moving->GetElapsed()) +
                            " x=" + std::to_string(moving->GetFlightPosition().x) +
                            " y=" + std::to_string(moving->GetFlightPosition().y) +
                            " z=" + std::to_string(moving->GetFlightPosition().z));
                RequestFrameDump((std::filesystem::path(saveRoot_) / "trash-imported-inflight.bmp").u8string());
                saveTestStep_ = 2;
            }
        } else if (saveTestStep_ == 2 && Saves().LastResult().status == SaveGameResult::Status::Saved) {
            SaveTestLog("phase=save result=saved throws=" + std::to_string(throws_) + " hits=" + std::to_string(hits_));
            ThrowTrash(); // mutate the world after the snapshot; load must remove this second throw.
            const auto request = Saves().RequestLoad("round-current");
            if (request.status != SaveGameResult::Status::Accepted)
                throw std::runtime_error("Round SaveGame load request rejected: " + request.message);
            SaveTestLog("phase=save load-request=accepted ticket=" + std::to_string(request.ticket));
            saveTestStep_ = 3;
        } else if (saveTestStep_ == 3 && Saves().LastResult().status == SaveGameResult::Status::Failed) {
            SaveTestLog("phase=save result=failed message=" + Saves().LastResult().message);
            throw std::runtime_error("Round SaveGame load failed: " + Saves().LastResult().message);
        } else if (saveTestStep_ == 3 && Saves().LastResult().status == SaveGameResult::Status::Loaded) {
            auto* moving = FindMovingTrash(GetScene());
            if (throws_ != 1 || hits_ != 0 || !moving)
                throw std::runtime_error("Round state or in-flight projectile did not restore");
            SaveTestLog("phase=save result=loaded throws=" + std::to_string(throws_) + " hits=" +
                        std::to_string(hits_) + " elapsed=" + std::to_string(moving->GetElapsed()) +
                        " projectile=" + std::to_string(moving->GetProjectileId()) + " PASS");
            RequestFrameDump((std::filesystem::path(saveRoot_) / "trash-round-save-load.bmp").u8string());
            saveTestStep_ = 4;
        }
    } else if (saveTestMode_ == 2) {
        if (saveTestStep_ == 0) {
            const auto request = Saves().RequestLoad("round-current");
            if (request.status != SaveGameResult::Status::Accepted)
                throw std::runtime_error("Cross-process round load rejected: " + request.message);
            saveTestStep_ = 1;
        } else if (saveTestStep_ == 1 && Saves().LastResult().status == SaveGameResult::Status::Loaded) {
            auto* moving = FindMovingTrash(GetScene());
            if (throws_ != 1 || hits_ != 0 || !moving || moving->GetElapsed() < 0.48f)
                throw std::runtime_error("Cross-process round/projectile state differs from saved snapshot");
            SaveTestLog("phase=restart loaded throws=" + std::to_string(throws_) + " hits=" +
                        std::to_string(hits_) + " elapsed=" + std::to_string(moving->GetElapsed()) + " PASS");
            saveTestStep_ = 2;
        } else if (saveTestStep_ == 2 && hits_ == 1) {
            SaveTestLog("phase=restart resumed hits=" + std::to_string(hits_) + " throws=" +
                        std::to_string(throws_) + " PASS");
            saveTestStep_ = 3;
        }
    } else if (saveTestMode_ == 3) {
        if (saveTestStep_ < 3 && throws_ < 3 && throws_ == hits_ + misses_) {
            ThrowTrash();
            const char* names[] = {"Multi-material item", "Soda can", "Crumpled paper"};
            SaveTestLog("phase=types launched=" + std::string(names[(throws_ - 1) % 3]) +
                        " round=" + std::to_string(round_) + " aim=" + std::to_string(aimOffset_));
            saveTestStep_ = static_cast<int>(throws_);
        } else if (saveTestStep_ == 3 && throws_ == 3 && throws_ == hits_ + misses_) {
            SaveTestLog("phase=types complete hits=" + std::to_string(hits_) + " misses=" +
                        std::to_string(misses_) + " accuracy=" +
                        std::to_string(throws_ ? (100u * hits_ / throws_) : 0u) + "% round=" +
                        std::to_string(round_) + " PASS");
            RequestFrameDump((std::filesystem::path(saveRoot_) / "trash-three-items.bmp").u8string());
            saveTestStep_ = 4;
        }
    }
}

void ProjectGame::ThrowTrash()
{
    auto* target = GetScene().FindComponentByName("Bucket base");
    if (!target) {
        RegisterMiss("Bucket target is missing.");
        return;
    }

    const auto kindIndex = throws_ % 3;
    const auto kind = static_cast<TrashProjectile::Kind>(kindIndex);
    const char* names[] = {"Multi-material item", "Soda can", "Crumpled paper"};
    const float shapeDrift[] = {-0.08f, 0.12f, -0.18f};
    const float finalAim = (std::clamp)(aimOffset_ + shapeDrift[kindIndex], -3.0f, 3.0f);
    std::unique_ptr<GameComponent> projectile;
    if (throws_ == 0) {
        auto imported = std::make_unique<ImportedTrashProjectile>();
        imported->Configure(target->GetComponentId(), {0.0f, 0.7f, -5.0f}, 1.6f, finalAim);
        projectile = std::move(imported);
    } else {
        auto primitive = std::make_unique<TrashProjectileComponent>();
        primitive->Configure(kind, target->GetComponentId(), {0.0f, 0.7f, -5.0f}, 1.6f, finalAim);
        projectile = std::move(primitive);
    }
    const std::string name = std::string(names[throws_ % 3]) + " " + std::to_string(throws_ + 1);
    const char* componentType = throws_ == 0 ? "Trash.MultiMaterialProjectile" : "Trash.Projectile";
    const auto added = GetScene().AddComponent(name, projectile, componentType);
    if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred) {
        RegisterMiss("Could not launch trash.");
        return;
    }
    ++throws_;
    if (throws_ > 0 && throws_ % 3 == 0) ++round_;
    if (auto* ledger = dynamic_cast<ProjectObjectComponent<ThrowLedger>*>(GetScene().FindComponentByName("Throw ledger")))
        { ledger->Value().throws = throws_; ledger->Value().round = round_; }
    if (GetProjectHud()) {
        GetProjectHud()->SetLabelText("status", std::string("Flying: ") + names[(throws_ - 1) % 3]);
        UpdateHud();
    }
}

void ProjectGame::RegisterHit()
{
    ++hits_;
    if (saveTestMode_ == 3) {
        auto* active = FindMovingTrash(GetScene());
        SaveTestLog(std::string("phase=types impact=hit item=") +
                    (dynamic_cast<ImportedTrashProjectile*>(active) ? "imported-multimaterial" : "primitive") +
                    " hits=" + std::to_string(hits_) + " misses=" + std::to_string(misses_) +
                    " throws=" + std::to_string(throws_));
    }
    if (impactBurstId_ == 0) {
        auto burst = std::make_unique<SceneProject::Sparks>();
        burst->SetParticleCount(64);
        burst->SetBaseLifetime(1.0f);
        burst->SetSpreadRadius(0.08f);
        burst->SetRadialSpeed(1.8f);
        burst->SetBaseVelocity({0.0f, 0.2f, 0.0f});
        burst->SetAcceleration({0.0f, -9.8f, 0.0f});
        burst->SetBaseSize(0.12f);
        burst->SetBrightness(1.6f);
        burst->SetRandomness(0.25f, 0.2f);
        burst->SetSimulationRate(1.0f);
        burst->SetDepthCollision(true);
        burst->SetSortingEnabled(true);
        if (auto* bucket = GetScene().FindComponentByName("Bucket base"))
            burst->SetPosition(bucket->GetWorldPosition() + glm::vec3(0.0f, 0.85f, 0.0f));
        else
            burst->SetPosition({0.0f, 0.9f, 5.2f});
        std::unique_ptr<GameComponent> component = std::move(burst);
        const auto added = GetScene().AddComponent("Hit sparks", component, "Particle.Sparks");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Could not create impact sparks");
        impactBurstId_ = added.id;
        impactBurstAge_ = 0.0f;
        if (std::getenv("TRASH_PARTICLE_TEST")) {
            particleFramesAfterHit_ = 0;
            SaveTestLog("backfill impact-burst created count=64 lifetime=1.0s collision=on sorting=on");
        }
    }
    if (auto* ledger = dynamic_cast<ProjectObjectComponent<ThrowLedger>*>(GetScene().FindComponentByName("Throw ledger")))
        { ledger->Value().hits = hits_; ledger->Value().misses = misses_; ledger->Value().throws = throws_; ledger->Value().round = round_; }
    if (GetProjectHud()) {
        GetProjectHud()->SetLabelText("status", "Hit! In the bucket.");
        UpdateHud();
    }
}

void ProjectGame::RegisterMiss(const std::string& reason)
{
    if (throws_ > hits_ + misses_) ++misses_;
    if (saveTestMode_ == 3) {
        auto* active = FindMovingTrash(GetScene());
        SaveTestLog(std::string("phase=types impact=miss item=") +
                    (dynamic_cast<ImportedTrashProjectile*>(active) ? "imported-multimaterial" : "primitive") +
                    " hits=" + std::to_string(hits_) + " misses=" + std::to_string(misses_) +
                    " throws=" + std::to_string(throws_) + " reason=" + reason);
    }
    if (auto* ledger = dynamic_cast<ProjectObjectComponent<ThrowLedger>*>(GetScene().FindComponentByName("Throw ledger"))) {
        ledger->Value().misses = misses_;
        ledger->Value().throws = throws_;
        ledger->Value().round = round_;
    }
    if (GetProjectHud())
        GetProjectHud()->SetLabelText("status", reason);
    UpdateHud();
}

void ProjectGame::AdjustAim(float delta)
{
    aimOffset_ = (std::clamp)(aimOffset_ + delta, -3.0f, 3.0f);
    if (GetProjectHud()) GetProjectHud()->SetLabelText("status", "Aim adjusted. Toss to check the bucket.");
    UpdateHud();
}

void ProjectGame::UpdateHud()
{
    if (GetProjectHud()) {
        GetProjectHud()->SetLabelText("score", std::string("Hits: ") + std::to_string(hits_) + " | Misses: " + std::to_string(misses_) + " | Tosses: " + std::to_string(throws_));
        const uint32_t settled = hits_ + misses_;
        const uint32_t accuracy = settled ? 100u * hits_ / settled : 0u;
        GetProjectHud()->SetLabelText("round", std::string("Round ") + std::to_string(round_) +
            " | " + std::to_string(accuracy) + "% accuracy");
        std::ostringstream aim;
        aim << "Aim: " << std::fixed << std::setprecision(2) << aimOffset_ << " m | L/R; T/Space toss";
        GetProjectHud()->SetLabelText("aim", aim.str());
    }
}

void ProjectGame::SerializeSaveGame(SaveArchive& archive)
{
    Game::SerializeSaveGame(archive);
    archive.Section("Trash.Round", [&](SaveArchive& state) {
        state.Version(1);
        state.Field("round", round_);
        state.Field("throws", throws_);
        state.Field("hits", hits_);
        state.Field("misses", misses_);
        state.Field("aimOffset", aimOffset_);
        if (hits_ + misses_ > throws_ || aimOffset_ < -3.0f || aimOffset_ > 3.0f)
            throw std::runtime_error("Invalid saved trash round");
    });
}

void ProjectGame::OnSaveGameLoaded()
{
    BindInputActions();
    if (auto* ledger = dynamic_cast<ProjectObjectComponent<ThrowLedger>*>(GetScene().FindComponentByName("Throw ledger"))) {
        ledger->Value().throws = throws_;
        ledger->Value().hits = hits_;
        ledger->Value().round = round_;
        ledger->Value().misses = misses_;
    }
    UpdateHud();
}

void ProjectGame::BindInputActions()
{
    auto& input = GetInput();
    const auto bind = [&input](const char* action, Keys key) {
        Input::Binding binding;
        binding.action = action;
        binding.context = Input::Context::Game;
        binding.chord = {key};
        input.Bind(binding);
    };
    bind("Trash.Throw", Keys::T);
    bind("Trash.Throw", Keys::Space);
    bind("Trash.AimLeft", Keys::Left);
    bind("Trash.AimRight", Keys::Right);
    bind("Trash.Save", Keys::F6);
    bind("Trash.Load", Keys::F9);
    throwConnection_ = input.Subscribe(throwScope_, Input::Context::Game, "Trash.Throw", Input::Phase::Pressed,
        [this](const Input::Event& event) { if (!event.cancelled) ThrowTrash(); });
    aimLeftConnection_ = input.Subscribe(throwScope_, Input::Context::Game, "Trash.AimLeft", Input::Phase::Pressed,
        [this](const Input::Event& event) { if (!event.cancelled) AdjustAim(-0.25f); });
    aimRightConnection_ = input.Subscribe(throwScope_, Input::Context::Game, "Trash.AimRight", Input::Phase::Pressed,
        [this](const Input::Event& event) { if (!event.cancelled) AdjustAim(0.25f); });
    saveConnection_ = input.Subscribe(throwScope_, Input::Context::Game, "Trash.Save", Input::Phase::Pressed,
        [this](const Input::Event& event) { if (!event.cancelled) Saves().RequestSave("round-current"); });
    loadConnection_ = input.Subscribe(throwScope_, Input::Context::Game, "Trash.Load", Input::Phase::Pressed,
        [this](const Input::Event& event) { if (!event.cancelled) Saves().RequestLoad("round-current"); });
}

void ProjectGame::SaveTestLog(const std::string& line) const
{
    std::ofstream log(std::filesystem::path(saveRoot_) / "RoundSaveTest.log", std::ios::app);
    log << line << '\n';
    if (!log) throw std::runtime_error("Cannot write RoundSaveTest.log");
}

void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }



