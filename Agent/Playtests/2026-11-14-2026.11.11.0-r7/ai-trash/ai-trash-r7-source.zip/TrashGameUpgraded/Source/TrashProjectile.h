#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/MeshComponent.h>
#include "TrashFlight.h"

class TrashProjectile : public MeshComponent, public TrashFlight
{
public:
    enum class Kind { Box, Can, CrumpledPaper };

    TrashProjectile();
    void Configure(Kind kind, uint64_t targetId, const glm::vec3& start, float duration, float aimOffset = 0.0f);
    void Tick(float deltaTime) override;
    bool IsResolved() const override { return resolved_; }
    float GetElapsed() const override { return elapsed_; }
    uint64_t GetProjectileId() const override { return GetComponentId(); }
    glm::vec3 GetFlightPosition() const override { return GetLocalPosition(); }
    Kind GetKind() const { return kind_; }
    void SerializeSaveGame(SaveArchive& archive) override;

private:
    uint64_t targetId_ = 0;
    glm::vec3 start_{0.0f, 0.7f, -5.0f};
    float elapsed_ = 0.0f;
    float duration_ = 1.6f;
    bool resolved_ = false;
    float aimOffset_ = 0.0f;
    Kind kind_ = Kind::Box;
};

ENGINE_COMPONENT("Thrown trash", "Trash.Projectile")
class TrashProjectileComponent : public TrashProjectile
{
public:
    TrashProjectileComponent() = default;
};
