#pragma once

#include <cstdint>
#include <glm/vec3.hpp>

class TrashFlight
{
public:
    virtual ~TrashFlight() = default;
    virtual bool IsResolved() const = 0;
    virtual float GetElapsed() const = 0;
    virtual uint64_t GetProjectileId() const = 0;
    virtual glm::vec3 GetFlightPosition() const = 0;
};
