#include "ThrowLane.h"

ThrowLane::ThrowLane()
{
    SetColor({0.21f, 0.24f, 0.27f, 1.0f});
}
