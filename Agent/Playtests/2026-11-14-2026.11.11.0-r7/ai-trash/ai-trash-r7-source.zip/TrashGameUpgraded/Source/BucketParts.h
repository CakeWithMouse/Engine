#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>
#include <Engine/Components/SpecificComponents/MeshComponent.h>

ENGINE_COMPONENT("Bucket wall", "Trash.BucketWall")
class BucketWall : public CubeComponent
{
public:
    BucketWall();
};

ENGINE_COMPONENT("Bucket scoring base", "Trash.BucketBase")
class BucketBase : public MeshComponent
{
public:
    BucketBase();
};
