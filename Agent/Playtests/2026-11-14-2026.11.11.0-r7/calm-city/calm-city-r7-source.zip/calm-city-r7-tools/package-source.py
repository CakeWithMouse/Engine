from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
project=Path(r'E:\Engine\Engine\build\playtests\20261114-r7\calm-city\CalmCityUpgraded')
tools=Path(r'E:\Engine\Engine\build\playtests\20261114-r7\calm-city\tools')
out=Path(r'E:\Engine\Agent\Playtests\2026-11-14-2026.11.11.0-r7\calm-city\calm-city-r7-source.zip')
keep_root={'Project.json','Project.code.json','Engine.lock.json','Build.ps1','ProjectTypes.tsv','Game.sln','Game.vcxproj'}
blocked_dirs={'Binaries','Intermediate','SaveData','EngineStore','.vs','.shadow_cache','__pycache__'}
blocked_suffix={'.dll','.exe','.pdb','.ilk','.obj','.lib','.exp','.idb','.pch'}
with ZipFile(out,'w',ZIP_DEFLATED,compresslevel=7) as z:
 for base in (project/'Source',project/'Content'):
  for p in base.rglob('*'):
   if not p.is_file() or any(part in blocked_dirs for part in p.relative_to(project).parts): continue
   if p.suffix.lower() in blocked_suffix: continue
   z.write(p,(Path('CalmCityUpgraded')/p.relative_to(project)).as_posix())
 for name in keep_root:
  p=project/name
  if p.is_file(): z.write(p,(Path('CalmCityUpgraded')/p.name).as_posix())
 for p in tools.iterdir():
  if not p.is_file() or p.suffix.lower() not in {'.py','.ps1','.cpp','.md'}: continue
  if p.suffix.lower() in blocked_suffix or p.name == 'LoopbackCapture.cpp': continue
  z.write(p,Path('calm-city-r7-tools')/p.name)
with ZipFile(out) as z:
 names=z.namelist()
 assert all(not any(part in blocked_dirs for part in Path(n).parts) for n in names)
 assert all(Path(n).suffix.lower() not in blocked_suffix for n in names)
 print(f'{out} entries={len(names)} bytes={out.stat().st_size}')


