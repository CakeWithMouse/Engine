import struct,pathlib
for name in ['transparency-sort-front.bmp','transparency-sort-back.bmp','transparency-sort-orbit-resize.bmp']:
 p=pathlib.Path('Engine/build/playtests/20261114-r7/calm-city/results')/name
 b=p.read_bytes(); off=struct.unpack_from('<I',b,10)[0]; w,h=struct.unpack_from('<ii',b,18); bits=struct.unpack_from('<H',b,28)[0]; stride=((w*bits+31)//32)*4
 x,y=w//2,h//2; row=(h-1-y) if h>0 else y; i=off+row*stride+x*(bits//8)
 pix=b[i:i+bits//8]; rgb=tuple(reversed(pix[:3]))
 print(f'{name}: {w}x{abs(h)} {bits}bpp centerRGB={rgb}')
