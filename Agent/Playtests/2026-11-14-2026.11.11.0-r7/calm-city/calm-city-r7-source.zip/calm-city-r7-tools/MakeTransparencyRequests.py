import json,pathlib
root=pathlib.Path('E:/Engine/Engine/build/playtests/20261114-r7/calm-city')
glass='E:/Engine/Game/BasicExamples/Content/Materials/Glass.mat'
mesh_layers=[
 {'position':[0,0,0],'color':[1,0.15,0.15],'alpha':0.42,'rotation':[0,0,0]},
 {'position':[0,0,0.25],'color':[0.15,1,0.2],'alpha':0.42,'rotation':[0,0,45]},
 {'position':[0,0,0.5],'color':[0.15,0.3,1],'alpha':0.42,'rotation':[0,0,90]},
 {'position':[0.15,0,0.75],'color':[1,0.8,0.1],'alpha':0.36,'rotation':[20,15,0]},
 {'position':[0,0.1,1.0],'color':[0.8,0.2,1],'alpha':0.36,'rotation':[-18,0,30]},
 {'position':[0.1,0,1.25],'color':[0.1,0.9,1],'alpha':0.34,'rotation':[0,30,-25]},
 {'position':[-1.4,0,0.2],'color':[1,0.35,0.1],'alpha':0.3,'rotation':[0,0,0]},
 {'position':[1.4,0,0.4],'color':[0.1,0.6,1],'alpha':0.3,'rotation':[0,0,0]},
]
move=[[round(x+0.5,3),y,round(z-0.35,3)] for x,y,z in [l['position'] for l in mesh_layers]]
inter={'rendering':0,'width':320,'height':240,'orthographic':True,'groups':[{'material':glass,'kind':'mesh','width':2,'height':2,'geometry':'cross','layers':mesh_layers}],
 'frames':[{'camera':[0,2,8],'target':[0,0,0],'time':0,'image':str(root/'results/transparency-intersections-a.bmp')},
           {'camera':[2,2,7],'target':[0,0,0],'time':0.5,'positions':move,'width':480,'height':320,'image':str(root/'results/transparency-intersections-orbit.bmp')},
           {'camera':[0,2,4],'target':[0,0,0],'time':1.25,'positions':mesh_layers and [l['position'] for l in mesh_layers],'width':400,'height':240,'image':str(root/'results/transparency-intersections-dolly.bmp')} ]}
(root/'requests/transparency-intersections-calm.json').write_text(json.dumps(inter,indent=2)+'\n',encoding='utf-8')
crowd_layers=[{'position':[x,0,z],'color':[0.2+0.18*i,0.7-0.1*i,1.0-0.12*i],'alpha':0.45,'rotation':[0,90*i,0]} for i,(x,z) in enumerate([(-1,-0.5),(0,0),(1,0.5),(2,-0.5)])]
crowd={'rendering':1,'width':320,'height':240,'orthographic':True,'groups':[{'material':glass,'kind':'crowd','width':1.6,'height':1.6,'geometry':'cross','layers':crowd_layers,'lods':3,'lodDistances':[3,6,12],'lodScreenHeights':[0.6,0.25,0.1],'fade':0.15,'impostor':True}],
 'frames':[{'camera':[0,3,14],'target':[0,0,0],'time':0,'image':str(root/'results/transparency-crowd-far.bmp')},
           {'camera':[0,2,7],'target':[0,0,0],'time':0.6,'width':480,'height':320,'image':str(root/'results/transparency-crowd-near-resize.bmp')},
           {'camera':[1,2,18],'target':[0,0,0],'time':1.4,'width':400,'height':240,'image':str(root/'results/transparency-crowd-far-resize.bmp')} ]}
(root/'requests/transparency-crowd-calm.json').write_text(json.dumps(crowd,indent=2)+'\n',encoding='utf-8')
