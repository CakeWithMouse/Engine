import hashlib,json
from pathlib import Path
R=Path(__file__).resolve().parents[1]
data=json.loads((R/'results'/'skeletal-animation.json').read_text())
assert data['ok'] and len(data['frames'])==5
times=[0,.25,.5,.75,1]
rows=[]
for t,f in zip(times,data['frames']):
 assert f['count']==1 and f['slot']==0
 assert len(f['faces'])==6 and all(face['sha256'] for face in f['faces'])
 img=Path(f['image']);assert img.is_file() and img.stat().st_size>54
 rows.append({'time':t,'faceHashes':[x['sha256'] for x in f['faces']],'occupiedTexels':[x['occupied'] for x in f['faces']],'image':img.name,'imageSha256':hashlib.sha256(img.read_bytes()).hexdigest()})
signatures=[tuple(r['faceHashes']) for r in rows]
assert len(set(signatures))>=3,'animated imported skeletal model did not change shadow maps across time'
out={'scenario':'CesiumMan imported skeletal animation updates point-shadow depth cubemap','model':'Game/Battle/Content/Models/CesiumMan.glb','results':rows,'uniqueShadowMapStates':len(set(signatures))}
(R/'results'/'skeletal-animation-analysis.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
