from pathlib import Path
p=Path('Engine/build/playtests/20261114-r7/calm-city/CalmCityUpgraded/Content/Materials/TransparencyProbe')
p.mkdir(parents=True,exist_ok=True)
for name,color in [('RedGlass',(1.0,0.05,0.05)),('BlueGlass',(0.05,0.1,1.0))]:
    tint=','.join(map(str,color))
    mat={'version':1,'shader':name+'.hlsl','render':{'blend':'translucent','lighting':'unlit','castShadows':False},'params':{'Tint':[*color,1.0],'Opacity':0.5}}
    (p/(name+'.mat')).write_text(__import__('json').dumps(mat,indent=2)+'\n',encoding='utf-8')
    (p/(name+'.hlsl')).write_text(f'''cbuffer MaterialParams : register(b1)
{{
    float4 Tint = float4({tint}, 1.0f);
    float Opacity = 0.5f;
}};
void Surface(MaterialInput i, inout MaterialOutput o)
{{
    o.Albedo = Tint.rgb;
    o.Alpha = Opacity;
    o.AmbientModel = 0.0f;
}}
''',encoding='utf-8')
