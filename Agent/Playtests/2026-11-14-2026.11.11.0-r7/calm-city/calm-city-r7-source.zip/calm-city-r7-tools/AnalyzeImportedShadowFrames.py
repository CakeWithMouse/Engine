"""Compare imported model shadow casting on/off in actual ProjectGame GPU frames."""
import json,struct,hashlib
from pathlib import Path
R=Path(__file__).resolve().parents[1]
def read(name):
 p=R/'results'/name;b=p.read_bytes();off=struct.unpack_from('<I',b,10)[0];w,h=struct.unpack_from('<ii',b,18);bits=struct.unpack_from('<H',b,28)[0];stride=((w*bits+31)//32)*4
 def pixel(x,y):
  i=off+(h-1-y)*stride+x*(bits//8);return tuple(reversed(b[i:i+3]))
 return p,w,abs(h),pixel
pa,w,h,a=read('imported-shadow-on.bmp');pb,w2,h2,b=read('imported-shadow-off.bmp');assert (w,h)==(w2,h2)==(1000,500)
# Exclude the render diagnostics panel; ROI retains ground around the imported Suzanne.
roi=(0,0,550,500); changed=0;maxerr=0;examples=[]
for y in range(roi[1],roi[3]):
 for x in range(roi[0],roi[2]):
  c1=a(x,y);c2=b(x,y);e=max(abs(c1[i]-c2[i]) for i in range(3))
  if e>3:
   changed+=1;maxerr=max(maxerr,e)
   if len(examples)<12:examples.append({'xy':[x,y],'castOn':c1,'castOff':c2,'maxRGBDelta':e})
assert changed>=100 and maxerr>=16,(changed,maxerr)
result={'expected':'Same imported Suzanne scene and materials except render.castShadows true vs false; ground/city pixel ROI should change when model shadow is removed.','actual':{'resolution':[w,h],'roi':list(roi),'changedPixelsOver3':changed,'maxRGBDelta':maxerr,'examples':examples,'onSha256':hashlib.sha256(pa.read_bytes()).hexdigest(),'offSha256':hashlib.sha256(pb.read_bytes()).hexdigest()},'criteria':'At least 100 ROI pixels differ by >3; maximum RGB difference at least 16. Excludes the top-right counters overlay.'}
(R/'results'/'imported-shadow-analysis.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
