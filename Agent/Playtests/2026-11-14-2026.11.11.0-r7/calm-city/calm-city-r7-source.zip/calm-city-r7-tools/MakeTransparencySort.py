import json,pathlib
root=pathlib.Path('E:/Engine/Engine/build/playtests/20261114-r7/calm-city')
base=root/'CalmCityUpgraded/Content/Materials/TransparencyProbe'
for name in ('RedGlass','BlueGlass'):
 p=base/(name+'.mat'); m=json.loads(p.read_text()); m['render']['twoSided']=True; p.write_text(json.dumps(m,indent=2)+'\n')
red=str(base/'RedGlass.mat'); blue=str(base/'BlueGlass.mat')
groups=[{'material':red,'kind':'mesh','width':3.5,'height':3.5,'geometry':'cross','layers':[{'position':[0,0,-0.18],'color':[1,0,0],'alpha':0.5,'rotation':[0,0,0]}]},
         {'material':blue,'kind':'mesh','width':3.5,'height':3.5,'geometry':'cross','layers':[{'position':[0,0,0.18],'color':[0,0,1],'alpha':0.5,'rotation':[0,0,0]}]}]
frames=[{'camera':[0,0,8],'target':[0,0,0],'time':0,'image':str(root/'results/transparency-sort-front.bmp')},
        {'camera':[0,0,-8],'target':[0,0,0],'time':0.5,'image':str(root/'results/transparency-sort-back.bmp')},
        {'camera':[2,1,6],'target':[0,0,0],'time':1.0,'width':480,'height':320,'image':str(root/'results/transparency-sort-orbit-resize.bmp')}]
for mode in (0,1):
 req={'rendering':mode,'width':320,'height':240,'orthographic':True,'groups':groups,'frames':frames}
 (root/f'requests/transparency-sort-mode{mode}.json').write_text(json.dumps(req,indent=2)+'\n',encoding='utf-8')
