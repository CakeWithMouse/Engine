Texture2D BaseMap : register(t6);
void Surface(MaterialInput i, inout MaterialOutput o) { o.Albedo = BaseMap.Sample(MaterialSampler, i.UV).rgb; o.SpecularWeight = 0; }
