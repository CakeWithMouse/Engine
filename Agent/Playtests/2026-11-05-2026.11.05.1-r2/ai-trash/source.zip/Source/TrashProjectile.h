#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/MeshComponent.h>

class TrashProjectile : public MeshComponent
{
public:
    enum class Kind { Box, Can, CrumpledPaper };

    TrashProjectile();
    void Configure(Kind kind, uint64_t targetId, const glm::vec3& start, float duration, float aimOffset = 0.0f);
    void Tick(float deltaTime) override;
    bool IsResolved() const { return resolved_; }
    float GetElapsed() const { return elapsed_; }
    Kind GetKind() const { return kind_; }
    void SerializeSaveGame(SaveArchive& archive) override;

private:
    uint64_t targetId_ = 0;
    glm::vec3 start_{0.0f, 0.7f, -5.0f};
    float elapsed_ = 0.0f;
    float duration_ = 1.6f;
    bool resolved_ = false;
    float aimOffset_ = 0.0f;
    Kind kind_ = Kind::Box;
};

ENGINE_COMPONENT("Thrown trash", "Trash.Projectile")
class TrashProjectileComponent : public TrashProjectile
{
public:
    TrashProjectileComponent() = default;
};
