# Rebuild the Tired Bomber source archive

This is a source-only archive. It does not contain a Runtime, SDK, Game.dll, or intermediate build products and cannot launch before a successful project build.

1. Extract while preserving paths; `Project.json` expects `Content/Scenes/Main.scene.json` and `Content/Models/CesiumMan.glb`.
2. Use the matching Release Runtime/SDK recorded in `Engine.lock.json` (PainEngine 2026.11.05.2).
3. From the extracted project directory run `powershell -NoProfile -ExecutionPolicy Bypass -File .\Build.ps1 -Runtime "<matching Runtime folder>"`.
4. Verify build success and the activated Game.dll path in `Project.json`.
5. Launch with matching `EngineRuntime.exe --project "<project>\Project.json" --mode game`, or use the matching EngineLauncher smoke command for a three-frame startup check.

The archive is not directly runnable until rebuilt. No SDK or Runtime files were included.
