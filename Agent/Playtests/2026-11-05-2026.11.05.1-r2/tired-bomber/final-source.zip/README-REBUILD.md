# Rebuild the Tired Bomber source archive

This is a source-only archive. It does not contain a Runtime, SDK, Game.dll, or intermediate build products and cannot launch before a successful project build.

1. Extract while preserving paths. `Project.json` expects `Content/Scenes/Main.scene.json` and the optional skeletal probe asset at `Content/Models/CesiumMan.glb`.
2. Use the matching Release Runtime/SDK recorded in `Engine.lock.json` (PainEngine 2026.11.05.3).
3. From the extracted project directory run:

   `powershell -NoProfile -ExecutionPolicy Bypass -File .\Build.ps1 -Runtime "<matching Runtime folder>"`

4. Check that the project build succeeds and activates the Game.dll path in `Project.json`.
5. Launch with the matching Runtime: `EngineRuntime.exe --project "<project>\Project.json" --mode game`, or use the matching EngineLauncher smoke command for a three-frame startup check.

The original test project and the Runtime used to produce the evidence are separate from this archive. No SDK or Runtime files were included.
