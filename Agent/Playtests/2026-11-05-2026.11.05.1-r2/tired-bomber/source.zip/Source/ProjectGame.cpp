#include "ProjectGame.h"
#include "ProjectComponent.h"
#include <Engine/Components/Character.h>
#include <Engine/MainGame/CharacterController.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/Components/SpecificComponents/InstancedMeshComponent.h>
#include <Engine/Components/SpecificComponents/ParticleSystemComponent.h>
#include <Engine/Render/MeshPrimitives.h>
#include <Engine/Render/MeshSimplifier.h>
#include <Engine/Render/MeshValidation.h>
#include <Engine/Runtime/ModuleVfs.h>
#include <Engine/Scene/Trace.h>
#include <Engine/SaveGame/SaveGame.h>
#include <algorithm>
#include <cmath>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <cstdlib>

namespace
{
ComponentId Add(Game& game, const std::string& name, std::unique_ptr<GameComponent> component, const std::string& type)
{
    const auto result = game.GetScene().AddComponent(name, component, type);
    if (result.result != SceneResult::Ok && result.result != SceneResult::Deferred)
        throw std::runtime_error("Cannot add playtest component: " + name);
    
    return result.id;
}
}

bool BomberSessionDiagnostics::Initialize(SubsystemContext&, std::string& error)
{
    error.clear();
    elapsed_ = 0.0f;
    std::cout << "[TiredBomber] subsystem initialized\n";
    return true;
}

void BomberSessionDiagnostics::OnSceneReady(Scene& scene)
{
    std::cout << "[TiredBomber] subsystem scene ready: " << scene.GetName() << "\n";
}

void BomberSessionDiagnostics::OnSceneClosing(Scene& scene)
{
    std::cout << "[TiredBomber] subsystem scene closing: " << scene.GetName() << "\n";
}

void BomberSessionDiagnostics::Tick(float deltaTime)
{
    elapsed_ += deltaTime;
    if (elapsed_ >= 5.0f)
    {
        elapsed_ = 0.0f;
        std::cout << "[TiredBomber] subsystem tick alive\n";
    }
}

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    Saves().Configure("tired-bomber-round", EngineModuleVfs::Resolve("/Game") + "/SaveSlots");
    if (const char* slot = std::getenv("TB_CONTROLLER_LOAD"); slot && *slot)
    {
        const auto request = Saves().RequestLoad(slot);
        std::cout << "[TiredBomber] controller-probe load request=" << static_cast<int>(request.status) << " slot=" << slot << "\n";
    }
    else if (const char* slot = std::getenv("TB_LOAD_SLOT"); slot && *slot)
    {
        const auto request = Saves().RequestLoad(slot);
        std::cout << "[TiredBomber] startup load request=" << static_cast<int>(request.status) << " slot=" << slot << "\n";
    }
    if (std::getenv("TB_START_PAUSED")) SetSimulationEnabled(false);
    SetSimulationTimeScale(1.0f);
    SetShadowSettings(false, 0.0f);
    GetSettings().SetVSync(false);
    GetSettings().SetAntialiasing(1);
    GetSettings().SetRenderingType(Forward);
    std::cout << "[TiredBomber] settings vsync=" << GetSettings().IsVSyncEnabled()
              << " aa=" << GetSettings().GetAntialiasing()
              << " mode=" << GetSettings().GetRenderingType()
              << " adapter=" << GetAdapterName() << "\n";
    const auto gameRoot = EngineModuleVfs::Resolve("/Game");
    if (!gameRoot.empty()) RequestFrameDump(gameRoot + "/tired-bomber-frame.bmp");

    if (auto* floor = GetScene().FindComponentByName("Ground"))
        floor_ = floor->GetComponentId();

    for (int i = 0; i < 4; ++i)
    {
        auto unit = std::make_unique<BomberPiece>();
        unit->SetPrimitive(MeshPrimitives::Cube(1.0f));
        unit->SetScale({1.2f, 0.6f, 0.75f});
        unit->SetPosition({-6.0f + i * 4.0f, 0.42f, (i % 2 ? 2.0f : -2.0f)});
        unit->SetColor(i % 2 ? glm::vec4(0.18f, 0.48f, 0.85f, 1.0f) : glm::vec4(0.85f, 0.32f, 0.16f, 1.0f));
        unit->traceChannels = 2u;
        units_.push_back(Add(*this, "Bomber.Unit." + std::to_string(i + 1), std::move(unit), "BomberPiece"));
    }

    auto instances = std::make_unique<BomberMarkers>();
    instances->SetLod(0, MeshPrimitives::Cube());
    instances->SetAutoLod({0.5f, 0.25f});
    instances->SetLodDistances({9.0f, 17.0f});
    instances->SetLodDebugColors(true);
    instances->SetDrawDistance(60.0f);
    instances->ReserveInstances(13);
    for (int i = 0; i < 6; ++i)
    {
        for (int side : {-1, 1})
        {
            MeshInstance marker;
            marker.Position = {-8.0f + float(i) * 3.2f, 0.2f, float(side) * 6.0f};
            marker.Scale = 0.35f;
            marker.Color = side < 0 ? glm::vec4(0.20f, 0.70f, 0.38f, 1.0f) : glm::vec4(0.35f, 0.60f, 0.90f, 1.0f);
            instances->AddInstance(marker);
        }
    }
    MeshInstance outsideView;
    outsideView.Position = {40.0f, 0.2f, 0.0f};
    outsideView.Scale = 0.35f;
    outsideView.Color = {0.9f, 0.2f, 0.8f, 1.0f};
    instances->AddInstance(outsideView); // inside draw distance, outside the camera frustum
    instances->SetInstanceVisible(0, false); // explicit per-instance visibility filter
    markers_ = instances.get();
    Add(*this, "Bomber.Markers.LOD", std::move(instances), "BomberMarkers");

    auto screenProbe = std::make_unique<BomberMarkers>();
    screenProbe->SetLod(0, MeshPrimitives::Cube());
    screenProbe->SetAutoLod({0.5f, 0.25f});
    screenProbe->SetLodScreenHeights({50.0f, 20.0f});
    screenProbe->SetLodDebugColors(true);
    MeshInstance probe;
    probe.Position = {0.0f, 0.0f, 0.0f};
    probe.Scale = 1.0f;
    probe.Color = {0.95f, 0.88f, 0.22f, 1.0f};
    screenProbe->AddInstance(probe);
    Add(*this, "Bomber.LOD.ScreenHeightProbe", std::move(screenProbe), "BomberMarkers");

    const auto cube = MeshPrimitives::Cube();
    const auto validation = ValidateMesh(cube);
    MeshValidationSettings cubeSettings;
    cubeSettings.MinLengthMeters = 0.25f;
    cubeSettings.PivotGroundTolerance = 0.6f;
    cubeSettings.PivotCenterTolerance = 0.5f;
    cubeSettings.bExpectNoseAlongZ = false;
    const auto configuredValidation = ValidateMesh(cube, cubeSettings);
    MeshSimplifyResult simplifyResult;
    MeshSimplifySettings simplifySettings;
    simplifySettings.TargetRatio = 0.5f;
    const auto lowerLod = SimplifyMesh(cube, simplifySettings, &simplifyResult);
    std::cout << "[TiredBomber] mesh check usable=" << validation.IsUsable()
              << " triangles=" << validation.Triangles << " configured=" << configuredValidation.IsUsable()
              << " lowLOD=" << simplifyResult.ResultTriangles
              << " error=" << simplifyResult.Error << "\n";
    std::cout << validation.ToText("procedural cube (default unit profile)") << "\n";

    auto camera = std::make_unique<SceneCamera>();
    camera->orthographic = true;
    camera->viewPlane = 2;
    camera->orthoHeight = 24.0f;
    camera->nearClip = 0.1f;
    camera->farClip = 100.0f;
    camera->SetPosition({0.0f, 24.0f, 0.0f});
    diagnosticsCamera_ = camera.get();
    const ComponentId cameraId = Add(*this, "Bomber.Camera", std::move(camera), "Gameplay.Camera");
    cameraId_ = cameraId;
    SetRenderDiagnosticsVisible(true);
    auto player = std::make_unique<Character>();
    player->SetPosition({-10.0f, 0.5f, 5.0f});
    player->SetPlayerControlled(true);
    player->standardControl = true;
    if (std::getenv("TB_CONTROLLER_PROBE")) {
        player->camera = 0;
        player->cameraSettings.viewPlane = 0;
    } else player->camera = cameraId;
    player_ = Add(*this, "Bomber.Player", std::move(player), "Gameplay.Character");

    if (!units_.empty())
    {
        const auto* firstUnit = GetScene().FindComponent(units_.front());
        const auto unitPos = firstUnit ? firstUnit->GetLocalPosition() : glm::vec3(-6, 0.42f, -2);
        for (uint32_t channel : {1u, 2u})
        {
            Trace::Query filter;
            filter.channels = channel;
            const Trace::Ray probe{{unitPos.x, 3.0f, unitPos.z}, {0, -1, 0}, 8.0f};
            const auto result = GetScene().Raycast(probe, filter);
            const char* hitName = result.hit && result.hit->componentId == units_.front() ? "unit" :
                result.hit && result.hit->componentId == floor_ ? "ground" : Trace::StatusName(result.status);
            std::cout << "[TiredBomber] trace filter channel=" << channel << " -> " << hitName << "\n";
        }
    }

    Input::Binding dropBinding;
    dropBinding.action = "Bomber.Drop";
    dropBinding.context = Input::Context::Game;
    dropBinding.chord = {Keys::B};
    GetInput().Bind(std::move(dropBinding));
    inputConnections_.push_back(GetInput().Subscribe(inputScope_, Input::Context::Game,
        "Bomber.Drop", Input::Phase::Pressed, [this](const Input::Event& event) {
            if (!event.cancelled) {
                bombTimer_ = 0.0f;
                std::cout << "[TiredBomber] input B: request bomb drop\n";
            }
        }));
    Input::Binding saveBinding;
    saveBinding.action = "Bomber.Save";
    saveBinding.context = Input::Context::Game;
    saveBinding.chord = {Keys::F6};
    GetInput().Bind(std::move(saveBinding));
    inputConnections_.push_back(GetInput().Subscribe(inputScope_, Input::Context::Game,
        "Bomber.Save", Input::Phase::Pressed, [this](const Input::Event& event) {
            if (!event.cancelled) {
                const auto result = Saves().RequestSave("round-1");
                std::cout << "[TiredBomber] save request status=" << static_cast<int>(result.status) << "\n";
            }
        }));
    Input::Binding pauseBinding;
    pauseBinding.action = "Bomber.PauseToggle";
    pauseBinding.context = Input::Context::Game;
    pauseBinding.chord = {Keys::P};
    GetInput().Bind(std::move(pauseBinding));
    inputConnections_.push_back(GetInput().Subscribe(inputScope_, Input::Context::Game,
        "Bomber.PauseToggle", Input::Phase::Pressed, [this](const Input::Event& event) {
            if (!event.cancelled) {
                SetSimulationEnabled(!IsSimulationEnabled());
                std::cout << "[TiredBomber] input P: simulation=" << IsSimulationEnabled() << "\n";
            }
        }));

    auto ui = std::make_unique<UIComponent>();
    ui->AddPanel({UIAnchor::TopLeft, 12, 12, 460, 54}, {0.03f, 0.05f, 0.08f, 0.88f});
    auto* label = ui->AddLabel({UIAnchor::TopLeft, 24, 22, 438, 32}, "Tired Bomber | hits 0 | misses 0", {0.94f, 0.96f, 1.0f, 1.0f});
    label->Name = "score";
    hud_ = ui.get();
    Add(*this, "Bomber.HUD", std::move(ui), "BomberHud");
    std::cout << "[TiredBomber] scene ready: 4 moving units, orthographic XZ camera, W/A/S/D controller, B drops a bomb\n";
}

void ProjectGame::SerializeSaveGame(SaveArchive& archive)
{
    Game::SerializeSaveGame(archive);
    archive.Section("TiredBomber.Round", [&](SaveArchive& state) {
        state.Version(1);
        state.Field("elapsed", elapsed_);
        state.Field("bombTimer", bombTimer_);
        state.Field("hits", hits_);
        state.Field("misses", misses_);
        uint64_t target = static_cast<uint64_t>(targetIndex_);
        state.Field("targetIndex", target);
        if (state.IsReading()) targetIndex_ = static_cast<size_t>(target);
        state.Field("sparksTimer", sparksTimer_);
        uint64_t unitCount = static_cast<uint64_t>(units_.size());
        state.Field("unitCount", unitCount);
        if (state.IsReading()) units_.resize(static_cast<size_t>(unitCount));
        uint64_t id = 0;
        auto reference = [&](const char* name, ComponentId& value) {
            id = value;
            state.Reference(name, id);
            if (state.IsReading()) value = id;
        };
        reference("player", player_);
        reference("floor", floor_);
        reference("activeBomb", activeBomb_);
        reference("sparks", sparksId_);
        reference("camera", cameraId_);
        for (size_t i = 0; i < static_cast<size_t>(unitCount); ++i) {
            const std::string key = "unit" + std::to_string(i);
            id = units_[i];
            state.Reference(key.c_str(), id);
            if (state.IsReading()) units_[i] = id;
        }
    });
}

void ProjectGame::OnSaveGameLoaded()
{
    diagnosticsCamera_ = nullptr;
    if (auto* camera = GetScene().FindComponentByName("Bomber.Camera"))
    {
        diagnosticsCamera_ = dynamic_cast<SceneCamera*>(camera);
        cameraId_ = camera->GetComponentId();
    }
    units_.clear();
    for (int i = 1; i <= 4; ++i)
        if (auto* unit = GetScene().FindComponentByName("Bomber.Unit." + std::to_string(i)))
            units_.push_back(unit->GetComponentId());
    hud_ = dynamic_cast<UIComponent*>(GetScene().FindComponentByName("Bomber.HUD"));
    markers_ = dynamic_cast<InstancedMeshComponent*>(GetScene().FindComponentByName("Bomber.Markers.LOD"));
    sparksId_ = 0;
    if (auto* sparks = GetScene().FindComponentByName("Bomber.HitSparks")) sparksId_ = sparks->GetComponentId();
    std::cout << "[TiredBomber] loaded round elapsed=" << elapsed_ << " hits=" << hits_
              << " misses=" << misses_ << " units=" << units_.size()
              << " activeBomb=" << activeBomb_ << " sparks=" << sparksId_
              << " sparksTimer=" << sparksTimer_ << " simulation=" << IsSimulationEnabled() << "\n";
    if (!IsSimulationEnabled() && std::getenv("TB_RESUME_AFTER_LOAD")) {
        SetSimulationEnabled(true);
        std::cout << "[TiredBomber] explicit resume after loaded pause in OnSaveGameLoaded\n";
    }
}

void ProjectGame::DropBomb()
{
    if (activeBomb_) return;
    auto bomb = std::make_unique<BomberPiece>();
    bomb->SetPrimitive(MeshPrimitives::Sphere(0.38f, 16, 8));
    targetIndex_ = static_cast<size_t>((hits_ + misses_) % static_cast<int>(units_.size()));
    const auto* target = GetScene().FindComponent(units_[targetIndex_]);
    const auto targetPosition = target ? target->GetLocalPosition() : glm::vec3(0, 0.42f, 0);
    bomb->SetPosition({targetPosition.x, 10.0f, targetPosition.z});
    bomb->SetColor({0.96f, 0.78f, 0.10f, 1.0f});
    activeBomb_ = Add(*this, "Bomber.ActiveBomb", std::move(bomb), "BomberPiece");
    std::cout << "[TiredBomber] bomb released at t=" << elapsed_ << "s\n";
}

void ProjectGame::PreUpdate(float deltaTime)
{
    Game::PreUpdate(deltaTime);
    ++diagnosticsFrame_;
    if (std::getenv("TB_CONTROLLER_PROBE"))
    {
        auto* controller = GetCharacterController();
        if (diagnosticsFrame_ == 3 && controller && !std::getenv("TB_CONTROLLER_LOAD"))
        {
            controller->SetEnabled(false);
            const auto request = Saves().RequestSave("controller-before");
            std::cout << "[ControllerProbe] disabled and saved status=" << static_cast<int>(request.status) << "\n";
        }
        if (diagnosticsFrame_ == 4 || (diagnosticsFrame_ >= 5 && diagnosticsFrame_ <= 10))
        {
            GetInput().SetKey(Keys::W, true);
            GetInput().SetKey(Keys::RightButton, true);
            GetInput().AddPointer(60.0f, 0.0f);
        }
        if (diagnosticsFrame_ == 12)
        {
            GetInput().SetKey(Keys::W, false);
            GetInput().SetKey(Keys::RightButton, false);
        }
        if (diagnosticsFrame_ == 20)
        {
            auto* character = GetScene().FindComponentByName("Bomber.Player");
            const auto position = character ? character->GetWorldPosition() : glm::vec3(0.0f);
            const auto cameraPosition = GetPlayer()->GetPosition();
            std::cout << "[ControllerProbe] frame=20 sim=" << IsSimulationEnabled()
                      << " character=" << position.x << "," << position.y << "," << position.z
                      << " camera=" << cameraPosition.x << "," << cameraPosition.y << "," << cameraPosition.z
                      << " cameraYaw=" << GetPlayer()->GetYaw() << "\n";
            if (std::getenv("TB_CONTROLLER_LOAD"))
            {
                const auto request = Saves().RequestSave("controller-after");
                std::cout << "[ControllerProbe] post-load input save status=" << static_cast<int>(request.status) << "\n";
            }
        }
    }
    if (const char* frameText = std::getenv("TB_SAVE_FRAME"); frameText && diagnosticsFrame_ == std::atoi(frameText)) {
        if (std::getenv("TB_PAUSE_BEFORE_SAVE")) SetSimulationEnabled(false);
        const auto result = Saves().RequestSave("round-1");
        std::cout << "[TiredBomber] save at frame=" << diagnosticsFrame_ << " status=" << static_cast<int>(result.status)
                  << " hits=" << hits_ << " misses=" << misses_ << " elapsed=" << elapsed_
                  << " sim=" << IsSimulationEnabled() << "\n";
    }
    if (WasLoadedFromSaveGame() && std::getenv("TB_RESUME_AFTER_LOAD") && diagnosticsFrame_ == 30) {
        SetSimulationEnabled(true);
        std::cout << "[TiredBomber] explicit resume after loaded pause at frame=30\n";
    }
    if (diagnosticsFrame_ == 101) {
        const auto& result = Saves().LastResult();
        std::cout << "[TiredBomber] save completion status=" << static_cast<int>(result.status)
                  << " ticket=" << result.ticket << " message=" << result.message << "\n";
    }
    if (!IsSimulationEnabled()) return;
    const auto gameRoot = EngineModuleVfs::Resolve("/Game");
    if (diagnosticsFrame_ == 60 && !gameRoot.empty())
        RequestFrameDump(gameRoot + "/lod-camera-24.bmp");
    if (diagnosticsFrame_ == 90 && diagnosticsCamera_)
    {
        diagnosticsCamera_->SetPosition({0.0f, 8.0f, 0.0f});
        std::cout << "[TiredBomber] diagnostics camera moved to Y=8 at frame " << diagnosticsFrame_ << "\n";
    }
    if (diagnosticsFrame_ == 130 && diagnosticsCamera_)
    {
        diagnosticsCamera_->SetPosition({0.0f, 24.0f, 0.0f});
        std::cout << "[TiredBomber] screen-height probe same orthoHeight=24 at camera Y=24\n";
    }
    if (diagnosticsFrame_ == 170 && diagnosticsCamera_)
    {
        diagnosticsCamera_->orthoHeight = 8.0f;
        std::cout << "[TiredBomber] screen-height probe zoom orthoHeight=8 at camera Y=24\n";
    }
    if (diagnosticsFrame_ == 110)
        std::cout << "[TiredBomber] completed-frame snapshot after near-camera move\n";
    if (diagnosticsFrame_ == 110 && !gameRoot.empty())
        RequestFrameDump(gameRoot + "/lod-camera-8.bmp");
    if (diagnosticsFrame_ == 150 && !gameRoot.empty())
        RequestFrameDump(gameRoot + "/lod-screenheight-ortho24-y24.bmp");
    if (diagnosticsFrame_ == 190 && !gameRoot.empty())
        RequestFrameDump(gameRoot + "/lod-screenheight-zoom8.bmp");
    if (diagnosticsFrame_ == 60 || diagnosticsFrame_ == 110 || diagnosticsFrame_ == 150 || diagnosticsFrame_ == 190)
    {
        const auto& completed = GetCompletedFrameStats();
        std::cout << "[TiredBomber] completed frame valid=" << completed.valid
                  << " index=" << completed.frameIndex << " draws=" << completed.counters.DrawCalls
                  << " instances=" << completed.counters.InstancesDrawn
                  << " visible=" << completed.counters.VisibleObjects
                  << " culled=" << completed.counters.CulledObjects << "\n";
        for (const auto& lod : completed.lodComponents)
        {
            std::cout << "[TiredBomber] LOD component=" << lod.name << " frame=" << lod.frameIndex
                      << " prepared=" << lod.prepared << " drawn=" << lod.drawn << "/" << lod.total
                      << " hidden=" << lod.hidden << " distance=" << lod.distanceCulled
                      << " frustum=" << lod.frustumCulled << " camera=";
            if (lod.hasDistance) std::cout << lod.minDistance << ".." << lod.maxDistance;
            else std::cout << "none";
            std::cout << " thresholds=";
            for (float threshold : lod.thresholds) std::cout << threshold << ",";
            std::cout << " perLOD=";
            for (uint32_t count : lod.perLod) std::cout << count << ",";
            std::cout << "\n";
        }
        for (const auto& line : GetRenderDiagnosticsLines()) std::cout << "[LOD panel] " << line << "\n";
    }
    elapsed_ += deltaTime;
    if (!sessionObserved_)
    {
        sessionObserved_ = true;
        std::cout << "[TiredBomber] GetSubsystem after startup="
                  << (GetSubsystem<BomberSessionDiagnostics>() ? "available" : "null") << "\n";
    }
    diagnosticsTimer_ += deltaTime;
    if (diagnosticsTimer_ >= 5.0f)
    {
        diagnosticsTimer_ = 0.0f;
        const auto& stats = GetFrameStats();
        std::cout << "[TiredBomber] frame stats draws=" << stats.DrawCalls
                  << " instances=" << stats.InstancesDrawn << " visible=" << stats.VisibleObjects
                  << " culled=" << stats.CulledObjects << " adapter=" << GetAdapterName() << "\n";
    }
    playerLogTimer_ += deltaTime;
    if (playerLogTimer_ >= 1.0f)
    {
        playerLogTimer_ = 0.0f;
        const auto* player = GetScene().FindComponent(player_);
        if (player)
        {
            const auto position = player->GetLocalPosition();
            std::cout << "[TiredBomber] player position x=" << position.x
                      << " y=" << position.y << " z=" << position.z
                      << " t=" << elapsed_ << "s\n";
        }
    }
    bombTimer_ -= deltaTime;
    for (size_t i = 0; i < units_.size(); ++i)
    {
        auto* unit = GetScene().FindComponent(units_[i]);
        if (!unit) continue;
        const float phase = elapsed_ * (0.8f + 0.12f * float(i)) + float(i) * 1.4f;
        unit->SetPosition({-6.0f + float(i) * 4.0f + std::sin(phase) * 1.35f,
                           0.42f, (i % 2 ? 2.0f : -2.0f) + std::cos(phase * 0.7f) * 0.55f});
    }
    if (!activeBomb_ && bombTimer_ <= 0.0f)
    {
        DropBomb();
        bombTimer_ = 2.8f;
    }
    auto* bomb = activeBomb_ ? GetScene().FindComponent(activeBomb_) : nullptr;
    if (bomb)
    {
        auto pos = bomb->GetLocalPosition();
        pos.y -= 9.0f * deltaTime;
        if (pos.y > 3.0f && targetIndex_ < units_.size())
            if (auto* target = GetScene().FindComponent(units_[targetIndex_]))
            {
                const auto targetPosition = target->GetLocalPosition();
                pos.x = targetPosition.x;
                pos.z = targetPosition.z;
            }
        bomb->SetPosition(pos);
        Trace::Ray ray{pos, {0.0f, -1.0f, 0.0f}, 1.0f};
        Trace::Query query;
        query.geometry = Trace::Geometry::Exact;
        query.ignore.push_back(activeBomb_);
        const auto result = GetScene().Raycast(ray, query);
        DebugDrawTrace(ray, result, 0.15f);
        if (result)
        {
            const auto hitId = result.hit->componentId;
            const bool hitUnit = std::find(units_.begin(), units_.end(), hitId) != units_.end();
            if (hitUnit)
            {
                ++hits_;
                std::cout << "[TiredBomber] HIT unit id=" << hitId << " t=" << elapsed_
                          << "s trace=" << Trace::StatusName(result.status)
                          << " queries=" << GetScene().GetTraceStatistics().queries
                          << " triangles=" << GetScene().GetTraceStatistics().triangles << "\n";
                pendingHitDumpFrames_ = 3;
                if (!sparksId_)
                {
                    auto sparks = std::make_unique<BomberSparks>(result.hit->position,
                        glm::vec3(0), glm::vec3(1), glm::vec4(1.0f, 0.5f, 0.12f, 0.95f));
                    sparks->SetParticleCount(256);
                    sparks->SetBaseLifetime(0.9f);
                    sparks->SetSpreadRadius(0.45f);
                    sparks->SetRadialSpeed(3.0f);
                    sparks->SetBaseVelocity({0.0f, 2.2f, 0.0f});
                    sparks->SetAcceleration({0.0f, -2.0f, 0.0f});
                    sparks->SetMaxDistance(5.0f);
                    sparks->SetBaseSize(0.12f);
                    sparks->SetDepthCollision(true);
                    sparks->SetDepthCollisionResponse(0.05f, 0.25f, 0.2f);
                    sparks->SetSortingEnabled(true);
                    sparksId_ = Add(*this, "Bomber.HitSparks", std::move(sparks), "BomberSparks");
                    sparksTimer_ = 1.4f;
                    std::cout << "[TiredBomber] GPU spark burst started (256, depth collision, sorting)\n";
                }
            }
            else if (hitId == floor_)
            {
                ++misses_;
                std::cout << "[TiredBomber] MISS floor t=" << elapsed_ << "s trace=" << Trace::StatusName(result.status) << "\n";
            }
            GetScene().RemoveComponent(activeBomb_);
            activeBomb_ = 0;
        }
    }
    if (sparksId_)
    {
        sparksTimer_ -= deltaTime;
        if (sparksTimer_ <= 0.0f)
        {
            GetScene().RemoveComponent(sparksId_);
            sparksId_ = 0;
        }
    }
    if (markers_ && markers_->GetDrawnInstances() != lastDrawnMarkers_)
    {
        lastDrawnMarkers_ = markers_->GetDrawnInstances();
        std::cout << "[TiredBomber] marker instances drawn=" << lastDrawnMarkers_
                  << " total=" << markers_->GetMeshInstanceCount() << " LODs=" << markers_->GetLodCount();
        for (int lod = 0; lod < markers_->GetLodCount(); ++lod)
            std::cout << " lod" << lod << "=" << markers_->GetDrawnInstancesForLod(lod);
        std::cout << "\n";
    }
    if (hud_)
        hud_->SetLabelText("score", "Tired Bomber | hits " + std::to_string(hits_) + " | misses " + std::to_string(misses_));
    if (pendingHitDumpFrames_ >= 0 && --pendingHitDumpFrames_ == 0)
    {
        const auto gameRoot = EngineModuleVfs::Resolve("/Game");
        if (!gameRoot.empty())
            RequestFrameDump(gameRoot + "/tired-bomber-hit-" + std::to_string(hits_) + ".bmp");
        pendingHitDumpFrames_ = -1;
    }
}





