#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include "Engine/Components/GameComponents.h"
#include <Engine/Components/SpecificComponents/InstancedMeshComponent.h>
#include <Engine/Components/SpecificComponents/ParticleSystemComponent.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
ENGINE_COMPONENT("ProjectComponent")
class ProjectComponent : public GameComponent
{
public:
    ProjectComponent() = default;
    void BeginPlay() override;
    void Tick(float deltaTime) override;
};

ENGINE_COMPONENT("Bomber Piece")
class BomberPiece final : public GameComponent {};
ENGINE_COMPONENT("Bomber Markers")
class BomberMarkers final : public InstancedMeshComponent {};
ENGINE_COMPONENT("Bomber Sparks")
class BomberSparks final : public ParticleSystemComponent {
public:
    using ParticleSystemComponent::ParticleSystemComponent;
};
ENGINE_COMPONENT("Bomber HUD")
class BomberHud final : public UIComponent {};
