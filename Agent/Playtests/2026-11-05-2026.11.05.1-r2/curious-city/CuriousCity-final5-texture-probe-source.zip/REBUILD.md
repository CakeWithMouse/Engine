# Curious City final .5 texture probe

This is the independent source-only copy used to verify BUG-R2-007 after the final .5 runtime fix. It includes `Source`, `Content`, `Project.json`, `Project.code.json`, `Engine.lock.json`, `Build.ps1`, `Game.vcxproj`, and `Game.sln`. It does not include a DLL, Binaries, Intermediate, or SDK.

## Build

Use Runtime 2026.11.05.5; the SDK `Engine.lib` SHA256 used for this check was `0FA010193F59C1BBE25B2CFA8EAAB70B51B8C08027E90A0273B9C6F2285F48FA`.

```powershell
.\Build.ps1 -Runtime 'E:\Engine\Engine\build\playtests\20261105-r2\final5\Runtime'
```

The probe source contains no `TrySetTexture` call. It only logs the restored `WestHome` texture path, `HasTexture`, `GetTexture`, and device/context state during PreUpdate.

## Reproduce the red/blue scene test

Copy `ProbeAssets\texture-red-2x2.bmp` to `Content\Images\Renamed.bmp`, then launch `EngineRuntime.exe --project <Project.json> --mode game --frames 50` with `CURIOUS_CITY_TEXTURE_PROBE` and `CURIOUS_CITY_FRAME_DUMP_PATH` pointing to separate log and BMP files. Repeat using `ProbeAssets\texture-blue-2x2.bmp`. Each frame dump is requested at frame 20. The tested scene is `Content\Scenes\Main.scene.json`; `WestHome` references `/Game/Images/Renamed.bmp`.

Expected on final .5: `HasTexture=1` and `GetTexture()!=nullptr` from frame 1 with no manual setter; the red and blue BMPs differ only in the WestHome color ROI.
