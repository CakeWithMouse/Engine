#include "CityInteractionComponent.h"
#include "CityEconomySubsystem.h"
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/SaveGame/SaveGame.h>
#include <cstdlib>
#include <filesystem>
#include <fstream>

namespace
{
    void RecordUiClick(const char* event)
    {
        const char* path = std::getenv("CURIOUS_CITY_LOG");
        if (!path) return;
        std::ofstream log(std::filesystem::u8path(path), std::ios::app);
        if (log) log << "event=" << event << '\n';
    }
}

void CityInteractionComponent::BeginPlay()
{
    GameComponent::BeginPlay();
    auto* game = GetGame();
    auto* economy = game ? game->GetSubsystem<CityEconomySubsystem>() : nullptr;
    auto* hud = game ? game->GetProjectHud() : nullptr;
    if (!economy || !hud) return;
    economy->AttachHud(hud);
    hud->BindClick("buildHouse", [economy, game] { RecordUiClick("build_ui_click"); economy->BuildOneHouse(game->GetScene()); });
    hud->BindClick("saveCity", [game] { RecordUiClick("save_ui_click"); game->Saves().RequestSave("city"); });
    hud->BindClick("loadCity", [game] { RecordUiClick("load_ui_click"); game->Saves().RequestLoad("city"); });
}
