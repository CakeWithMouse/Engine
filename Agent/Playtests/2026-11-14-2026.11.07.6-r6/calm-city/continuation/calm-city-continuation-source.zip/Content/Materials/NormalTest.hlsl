Texture2D NormalMap : register(t6);
void Surface(MaterialInput i, inout MaterialOutput o)
{
    o.Normal = NormalFromMap(i, NormalMap.Sample(MaterialSampler, i.UV).xyz, 1.0);
}
