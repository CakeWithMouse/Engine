cbuffer MaterialParams : register(b1)
{
    float4 Tint = float4(0.72f, 0.58f, 0.39f, 1.0f);
    float Gloss = 0.18f;
};

void Surface(MaterialInput i, inout MaterialOutput o)
{
    o.Albedo = Tint.rgb;
    o.SpecularWeight = Gloss;
    o.AmbientModel = 1.0f;
}
