#include "CityBuilding.h"
#include <Engine/Render/MeshPrimitives.h>

CityBuilding::CityBuilding()
{
    SetMesh(MeshPrimitives::Cube());
    SetColor({0.35f, 0.62f, 0.74f, 1.0f});
}
