#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/MeshComponent.h>

ENGINE_COMPONENT("City building", "CalmCity.Building")
class CityBuilding : public MeshComponent
{
public:
    CityBuilding();
};
