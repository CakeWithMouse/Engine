#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/PropertyMacros.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>
#include <Engine/InputDevice/InputActions.h>

ENGINE_COMPONENT("Car mover", "CalmCity.CarMover")
class CarMover : public CubeComponent
{
public:
    CarMover();
    ENGINE_GENERATED_PROPERTIES(CubeComponent)

    void Tick(float deltaTime) override;
    void BeginPlay() override;
    void SerializeSaveGame(SaveArchive& archive) override;

private:
    ENGINE_PROPERTY("Speed (world units/s)", 0.25, 6.0)
    float speed = 1.8f;
    ENGINE_PROPERTY("Moving")
    bool moving = true;
    bool goingRight = true;
    Input::Connection saveConnection_;
    Input::Connection loadConnection_;
    Input::Scope inputScope_;
};

