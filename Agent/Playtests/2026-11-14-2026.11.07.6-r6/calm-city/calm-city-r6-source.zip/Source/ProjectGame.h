#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/MainGame/BaseGameClass/Game.h>

ENGINE_GAME("ProjectGame")
class ProjectGame : public Game
{
public:
    void AfterInitialize() override;
    void PreUpdate(float deltaTime) override;
    void TickComponents(float deltaTime) override;

private:
    int saveTestMode_ = 0;
    int saveTestStep_ = 0;
    float saveTestX_ = 0.0f;
    bool frameDumpRequested_ = false;
};
