# Rebuild source archive

This source-only archive contains the current Tired Bomber project, game code, scenes, models, and project code metadata. It omits SDK files, game DLLs, `Binaries`, `Intermediate`, SaveSlots, and generated frame captures.

1. Create and enable a fresh C++ project with the 2026.11.07.6 Release launcher. Keep its matching runtime SDK available.
2. Copy the archive's `Source`, `Content/Models`, `Content/Scenes`, and root project metadata (`Project.json`, `Project.code.json`, `ProjectTypes.tsv`, project build files) into that project. Preserve the project's SDK installation; this archive does not contain an SDK.
3. `ProjectTypes.tsv` uses absolute source paths from the captured project root. Replace `E:\Engine\Engine\build\playtests\20261114-r6\tired-bomber\BomberUpgrade` with the extracted project root.
4. Build with `EngineLauncher.exe --build-project <Project.json>` or the included `Build.ps1 -Runtime <2026.11.07.6 Release Runtime>`.

Engine.lock.json pins PainEngine 2026.11.07.6 Release. The archived `Project.code.json` identifies the captured module path, but its DLL is intentionally omitted; rebuild it before launch.
