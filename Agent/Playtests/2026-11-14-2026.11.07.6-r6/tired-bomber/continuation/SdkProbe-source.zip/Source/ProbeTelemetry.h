#pragma once
#include <Engine/Runtime/ModuleVfs.h>
#include <filesystem>
#include <fstream>
#include <string>

inline void BomberProbeLog(const std::string& line)
{
    const auto path = EngineModuleVfs::Resolve("/Game/Config/probe-events.txt");
    if (path.empty()) return;
    std::ofstream stream(std::filesystem::u8path(path), std::ios::app);
    if (stream) stream << line << '\n';
}
