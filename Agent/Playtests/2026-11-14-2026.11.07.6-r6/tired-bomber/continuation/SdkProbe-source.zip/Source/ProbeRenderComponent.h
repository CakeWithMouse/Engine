#pragma once
#include <Engine/Components/SpecificComponents/CubeComponent.h>
#include <Engine/Components/ComponentAnnotations.h>

ENGINE_COMPONENT("Bomber Probe Render", "BomberProbe.Render")
class BomberProbeRenderComponent final : public CubeComponent
{
public:
    void CreateBuffers(ID3D11Device* device) override;
    void Render(ID3D11DeviceContext* context) override;
    unsigned renderCalls = 0;
    bool hadDevice = false;
    bool hadContext = false;
};
