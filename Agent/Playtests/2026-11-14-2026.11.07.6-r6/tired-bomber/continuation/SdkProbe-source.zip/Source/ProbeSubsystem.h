#pragma once
#include <Engine/MainGame/GameSubsystem.h>
#include "ProbeTelemetry.h"

ENGINE_SUBSYSTEM()
class BomberProbeSubsystem final : public GameSubsystem
{
public:
    BomberProbeSubsystem() { bTickEnabled = true; }
    bool Initialize(SubsystemContext&, std::string&) override
    {
        BomberProbeLog("subsystem.initialize");
        return true;
    }
    void OnSceneReady(Scene&) override { ++readyCount; BomberProbeLog("subsystem.scene-ready"); }
    void OnSceneClosing(Scene&) override { ++closingCount; BomberProbeLog("subsystem.scene-closing"); }
    void Tick(float dt) override
    {
        ++ticks;
        lastDt = dt;
    }
    void SerializeSaveGame(SaveArchive& archive) override;
    unsigned readyCount = 0;
    unsigned closingCount = 0;
    unsigned ticks = 0;
    float lastDt = 0.0f;
};
