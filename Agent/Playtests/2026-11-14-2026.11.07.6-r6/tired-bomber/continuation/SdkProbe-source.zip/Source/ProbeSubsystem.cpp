#include "ProbeSubsystem.h"
#include <Engine/SaveGame/SaveArchive.h>

void BomberProbeSubsystem::SerializeSaveGame(SaveArchive& archive)
{
    GameSubsystem::SerializeSaveGame(archive);
    archive.Section("BomberProbeSubsystem", [&](SaveArchive& section) {
        section.Version(1);
        section.Field("readyCount", readyCount);
        section.Field("closingCount", closingCount);
        section.Field("ticks", ticks);
        section.Field("lastDt", lastDt);
    });
}
