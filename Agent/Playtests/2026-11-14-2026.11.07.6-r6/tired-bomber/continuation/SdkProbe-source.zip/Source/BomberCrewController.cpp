#include "BomberCrewController.h"
void BomberCrewController::BeginPlay() { Character::BeginPlay(); }
void BomberCrewController::Tick(float deltaTime) { Character::Tick(deltaTime); }
