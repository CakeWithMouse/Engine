#pragma once
#include <Engine/MainGame/CharacterController.h>
#include "ProbeTelemetry.h"

class BomberProbeController final : public CharacterController
{
public:
    explicit BomberProbeController(Game& game) : CharacterController(game) {}
    void Tick(float seconds) override;
};
