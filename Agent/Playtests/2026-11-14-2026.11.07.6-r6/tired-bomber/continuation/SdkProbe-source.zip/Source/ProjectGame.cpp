#include "ProjectGame.h"
#include "RotatingCube.h"
#include "ProbeTelemetry.h"
#include "ProbeSubsystem.h"
#include "ProbeController.h"
#include "ProbeRenderComponent.h"
#include <Engine/Components/Character.h>
#include <Engine/Components/SpecificComponents/ParticleSystemComponent.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/Sound/AudioEngine.h>
#include <Engine/Sound/WavDecoder.h>
#include <Engine/SaveGame/SaveGame.h>
#include <Engine/Project/StandardTypes.h>
#include <filesystem>
#include <fstream>
#include <cstdlib>
#include <stdexcept>

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    // One full turn in four real seconds, independent of the frame rate.
    SetSimulationTimeScale(0.7f);
    auto& scene = GetScene();
    // A saved RotatingCube already supplies the example after loading/Play.
    for (const auto& entry : scene.GetComponents())
        if (dynamic_cast<RotatingCube*>(entry.second.get())) return;
    std::unique_ptr<GameComponent> cube = std::make_unique<RotatingCube>();
    cube->SetPosition({2.0f, 1.0f, 0.0f});
    std::string name = "RotatingCube";
    for (unsigned suffix = 2; scene.FindComponentByName(name); ++suffix)
        name = "RotatingCube" + std::to_string(suffix);
    const auto added = scene.AddComponent(name, cube, "RotatingCube");
    if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
        throw std::runtime_error("Cannot add the starter RotatingCube");

    if (!scene.FindComponentByName("BomberProbeGround")) {
        std::unique_ptr<GameComponent> ground = std::make_unique<SceneProject::Plane>();
        ground->SetPosition({0.0f, -0.5f, 0.0f});
        ground->SetScale({12.0f, 1.0f, 12.0f});
        const auto result = scene.AddComponent("BomberProbeGround", ground, "Primitive.Plane");
        if (result.result != SceneResult::Ok && result.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add BomberProbeGround");
    }

    if (!scene.FindComponentByName("BomberProbePilot")) {
        auto* player = new PlayerCharacter();
        player->SetPosition({-2.0f, 0.45f, 0.0f});
        player->standardControl = false;
        player->cameraSettings.orthographic = true;
        player->cameraSettings.viewPlane = 2;
        player->cameraSettings.orthoHeight = 14.0f;
        std::unique_ptr<GameComponent> pilot(player);
        const auto result = scene.AddComponent("BomberProbePilot", pilot, "Gameplay.Player");
        if (result.result != SceneResult::Ok && result.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add BomberProbePilot");
    }

    auto* renderProbe = new BomberProbeRenderComponent();
    renderProbe->SetPosition({-3.0f, 0.5f, 0.0f});
    renderProbe->SetScale({0.35f, 0.35f, 0.35f});
    if (RegisterComponent("BomberProbeRender", renderProbe) != RegisterResult::Ok)
        delete renderProbe;

    const char* collisionEnv = std::getenv("BOMBER_PROBE_COLLISION");
    const bool collision = !collisionEnv || std::string(collisionEnv) != "0";
    auto* particles = new SceneProject::Sparks();
    particles->SetPosition({0.0f, 0.25f, 0.0f});
    particles->SetParticleCount(1024);
    particles->SetBaseLifetime(4.0f);
    particles->SetBaseVelocity({0.0f, 1.5f, 0.0f});
    particles->SetAcceleration({0.0f, -4.0f, 0.0f});
    particles->SetDepthCollision(collision);
    particles->SetDepthCollisionResponse(0.08f, 0.82f, 0.12f);
    particles->SetSortingEnabled(true);
    if (RegisterComponent("BomberProbeParticles", particles) != RegisterResult::Ok)
        delete particles;

    auto* hud = new UIComponent();
    UIRect labelRect; labelRect.X = 16; labelRect.Y = 12; labelRect.Width = 240; labelRect.Height = 30;
    auto* label = hud->AddLabel(labelRect, "BOMB TEST · 0 hits", {1.0f, 1.0f, 1.0f, 1.0f});
    label->Name = "probe-hits";
    UIRect buttonRect; buttonRect.X = 16; buttonRect.Y = 50; buttonRect.Width = 220; buttonRect.Height = 38;
    hud->AddButton(buttonRect, "Register impact", [this, hud] {
        ++buttonClicks;
        BomberProbeLog("hud.button-click=" + std::to_string(buttonClicks));
        hud->SetLabelText("probe-hits", "BOMB TEST · " + std::to_string(buttonClicks) + " hits");
    });
    if (RegisterComponent("BomberProbeHud", hud) != RegisterResult::Ok)
        delete hud;

    const auto configPath = EngineModuleVfs::Resolve("/Game/Config/probe.txt");
    std::ifstream config(std::filesystem::u8path(configPath));
    std::string configLine;
    std::getline(config, configLine);
    BomberProbeLog("vfs.read=" + configLine);
    BomberProbeLog(std::string("vfs.audio-resolve=") + (EngineModuleVfs::Resolve("/Game/Audio/tone.wav").empty() ? "missing" : "found"));
    if (!configPath.empty()) {
        const auto contentRoot = std::filesystem::u8path(configPath).parent_path().parent_path();
        Saves().Configure("tired-bomber-probe", contentRoot / "SaveSlots");
    }

    const auto soundPath = EngineModuleVfs::Resolve("/Game/Audio/tone.wav");
    if (!soundPath.empty()) {
        audio::WavDecoder decoder;
        const bool opened = decoder.Open(std::filesystem::u8path(soundPath).wstring());
        if (opened) {
            const auto& format = decoder.GetFormat();
            std::vector<uint8_t> samples(size_t(format.blockAlign) * 64);
            const auto read = decoder.ReadFrames(samples.data(), 64);
            const bool seeked = decoder.SeekFrames(0);
            BomberProbeLog("audio.decode=" + std::to_string(format.sampleRate) + "," + std::to_string(decoder.GetLengthFrames()) + "," + std::to_string(read) + "," + std::to_string(seeked));
        } else {
            BomberProbeLog("audio.decode=failed");
        }
        auto* audio = GetAudioEngine();
        if (audio) {
            const auto sound = audio->LoadSound(std::filesystem::u8path(soundPath).wstring());
            BomberProbeLog("audio.load=" + std::to_string(sound.IsValid()));
            if (sound.IsValid()) {
                BomberProbeLog("audio.play2d=" + std::to_string(audio->Play2D(sound)));
                audio::AudioEmitter3D emitter; emitter.position = {2.0f, 0.0f, 1.0f}; emitter.Commit();
                BomberProbeLog("audio.play3d=" + std::to_string(audio->Play3D(sound, emitter)));
            }
            const auto stream = audio->PlayStream(std::filesystem::u8path(soundPath).wstring());
            BomberProbeLog("audio.stream=" + std::to_string(stream.IsValid()));
            if (stream.IsValid()) audio->StopStream(stream);
        }
    }

    const char* renderingEnv = std::getenv("BOMBER_PROBE_DEFERRED");
    GetSettings().SetRenderingType(renderingEnv && std::string(renderingEnv) == "1" ? Deffered : Forward);
    GetSettings().SetVSync(false);
    GetSettings().SetAntialiasing(renderingEnv && std::string(renderingEnv) == "1" ? 1u : 0u);
    BomberProbeLog("settings=" + std::to_string(int(GetSettings().GetRenderingType())) + "," + std::to_string(GetSettings().IsVSyncEnabled()) + "," + std::to_string(GetSettings().GetAntialiasing()));
}

void ProjectGame::PreUpdate(float deltaTime)
{
    Game::PreUpdate(deltaTime);
    if (auto* subsystem = GetSubsystem<BomberProbeSubsystem>())
        if (subsystem->ticks == 0) BomberProbeLog("subsystem.lookup=success");
}
void ProjectGame::TickComponents(float deltaTime)
{
    Game::TickComponents(deltaTime);
    if (auto* pilot = dynamic_cast<Character*>(GetScene().FindComponentByName("BomberProbePilot"))) {
        const auto p = pilot->GetWorldPosition();
        BomberProbeLog("pilot.position=" + std::to_string(p.x) + "," + std::to_string(p.y) + "," + std::to_string(p.z));
        if (!traceLogged) {
            Trace::Query query; query.maxDistance = 100; query.ignore.push_back(pilot->GetComponentId());
            const auto trace = RaycastScreen(Trace::ViewportPoint::Pixel(320, 240), query);
            std::string message = std::string("trace.screen=") + Trace::StatusName(trace.status);
            if (trace.hit) message += "," + std::to_string(trace.hit->position.x) + "," + std::to_string(trace.hit->position.y) + "," + std::to_string(trace.hit->position.z);
            BomberProbeLog(message);
            traceLogged = true;
        }
    }
    if (auto* render = dynamic_cast<BomberProbeRenderComponent*>(GetScene().FindComponentByName("BomberProbeRender")))
        if (render->renderCalls == 1) BomberProbeLog("render.host-hooks=" + std::to_string(render->hadDevice) + "," + std::to_string(render->hadContext));
    if (auto* subsystem = GetSubsystem<BomberProbeSubsystem>()) {
        if (!saveRequested && std::getenv("BOMBER_PROBE_SAVE") && subsystem->ticks >= 30) {
            saveRequested = true;
            BomberProbeLog("save.remove-particles=" + std::to_string(UnregisterComponent("BomberProbeParticles")));
            BomberProbeLog("save.remove-hud=" + std::to_string(UnregisterComponent("BomberProbeHud")));
            const auto result = Saves().RequestSave("probe-round");
            BomberProbeLog("save.request=" + std::to_string(int(result.status)));
        }
        if (!loadRequested && std::getenv("BOMBER_PROBE_LOAD") && subsystem->ticks >= 2) {
            loadRequested = true;
            const auto result = Saves().RequestLoad("probe-round");
            BomberProbeLog("load.request=" + std::to_string(int(result.status)));
        }
        const auto status = Saves().LastResult().status;
        if (status == SaveGameResult::Status::Saved && !saveReported) {
            BomberProbeLog("save.completed=ticks-" + std::to_string(subsystem->ticks));
            saveReported = true;
        }
        if (status == SaveGameResult::Status::Loaded && !loadReported) {
            BomberProbeLog("load.completed=ticks-" + std::to_string(subsystem->ticks));
            loadReported = true;
        }
        if (status == SaveGameResult::Status::Failed && !saveReported && (saveRequested || loadRequested)) {
            BomberProbeLog("save.load.failed=" + Saves().LastResult().message);
            saveReported = true;
        }
    }
}

std::unique_ptr<CharacterController> ProjectGame::CreateCharacterController()
{
    return std::make_unique<BomberProbeController>(*this);
}

