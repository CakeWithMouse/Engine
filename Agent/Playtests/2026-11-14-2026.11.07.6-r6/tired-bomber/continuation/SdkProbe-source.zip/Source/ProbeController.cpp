#include "ProbeController.h"
#include <Engine/Components/Character.h>

void BomberProbeController::Tick(float seconds)
{
    CharacterController::Tick(seconds);
    if (auto* character = GetCharacter())
    {
        character->Move({1.0f, 0.0f, 0.0f}, seconds);
        BomberProbeLog("controller.move");
    }
}
