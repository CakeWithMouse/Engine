#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/MainGame/CharacterController.h>

ENGINE_GAME("ProjectGame")
class ProjectGame : public Game
{
public:
    void AfterInitialize() override;
    void PreUpdate(float deltaTime) override;
    void TickComponents(float deltaTime) override;
    std::unique_ptr<CharacterController> CreateCharacterController() override;
private:
    unsigned buttonClicks = 0;
    bool traceLogged = false;
    bool saveRequested = false;
    bool loadRequested = false;
    bool saveReported = false;
    bool loadReported = false;
};
