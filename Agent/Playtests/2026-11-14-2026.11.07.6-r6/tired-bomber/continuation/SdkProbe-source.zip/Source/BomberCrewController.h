#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include "Engine/Components/Character.h"
ENGINE_COMPONENT("BomberCrewController")
class BomberCrewController : public Character
{
public:
    BomberCrewController() = default;
    void BeginPlay() override;
    void Tick(float deltaTime) override;
};
