#include "ProbeRenderComponent.h"

void BomberProbeRenderComponent::CreateBuffers(ID3D11Device* device)
{
    hadDevice = device != nullptr && GetGame() != nullptr && GetGame()->GetDevice() == device;
    CubeComponent::CreateBuffers(device);
}

void BomberProbeRenderComponent::Render(ID3D11DeviceContext* context)
{
    hadContext = context != nullptr && GetGame() != nullptr && GetGame()->GetContext() == context;
    ++renderCalls;
    CubeComponent::Render(context);
}
