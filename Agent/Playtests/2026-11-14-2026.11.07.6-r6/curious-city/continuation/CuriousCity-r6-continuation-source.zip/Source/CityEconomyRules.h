#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include "Engine/Components/ProjectObject.h"
ENGINE_OBJECT("CityEconomyRules")
class CityEconomyRules
{
public:
    CityEconomyRules() = default;

};
