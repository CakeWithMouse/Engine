# Tired Bomber R3 source archive

Source-only snapshot from the official .7-created CLI project used in the broad persona run. The source tree and imported game assets/scenes are included; generated SDK, Build/Intermediate/Binaries, DLL/PDB, runtime captures, and SaveSlots are excluded.

For the final narrow retest, the same project was upgraded with the frozen `2026.11.05.8` launcher and rebuilt in `Final8Bomber`. Rebuild from this archive by opening `Project.json` with the frozen final8 launcher and using its `--upgrade-project` workflow if the current project lock is older, then `--build-project`. The SDK is external and pinned through Engine.lock.json; none is vendored here.
