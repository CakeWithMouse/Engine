#include "R3WizardProbe.h"
void R3WizardProbe::BeginPlay() { CubeComponent::BeginPlay(); }
void R3WizardProbe::Tick(float deltaTime) { CubeComponent::Tick(deltaTime); }
