#include "BomberTarget.h"
void BomberTarget::BeginPlay() { CubeComponent::BeginPlay(); }
void BomberTarget::Tick(float deltaTime) { CubeComponent::Tick(deltaTime); }
