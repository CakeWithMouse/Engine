#include "RenderHostProbe.h"
#include <iostream>

void RenderHostProbe::Render(ID3D11DeviceContext* context)
{
    MeshComponent::Render(context);
    if (!reported_)
    {
        reported_ = true;
        std::cout << "[RenderHostProbe] Render context=" << (context ? "ready" : "null") << "\n";
    }
}
