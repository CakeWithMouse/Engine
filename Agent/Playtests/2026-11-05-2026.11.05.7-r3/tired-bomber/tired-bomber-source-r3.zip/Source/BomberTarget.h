#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include "Engine/Components/SpecificComponents/CubeComponent.h"
ENGINE_COMPONENT("BomberTarget")
class BomberTarget : public CubeComponent
{
public:
    BomberTarget() = default;
    void BeginPlay() override;
    void Tick(float deltaTime) override;
};
