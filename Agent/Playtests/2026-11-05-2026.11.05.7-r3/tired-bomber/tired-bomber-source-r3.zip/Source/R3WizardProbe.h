#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include "Engine/Components/SpecificComponents/CubeComponent.h"
ENGINE_COMPONENT("R3WizardProbe")
class R3WizardProbe : public CubeComponent
{
public:
    R3WizardProbe() = default;
    void BeginPlay() override;
    void Tick(float deltaTime) override;
};
