#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/MeshComponent.h>

ENGINE_COMPONENT("RenderHostProbe")
class RenderHostProbe final : public MeshComponent
{
public:
    void Render(ID3D11DeviceContext* context) override;
private:
    bool reported_ = false;
};
