#include "ProjectGame.h"
#include <Engine/AI/Tasks.h>
#include <Engine/Resources/Paths.h>
#include <Engine/Components/Light/PointLightComponent.h>
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <stdexcept>

namespace {
Ai::Key<Ai::ObjectRef> Target{"Target"};
constexpr uint32_t FloorTraceChannel=1u<<1;
constexpr uint32_t UnitTraceChannel=1u<<2;
const char* MoveStatusText(Ai::MoveStatus status) {
    switch(status) {
    case Ai::MoveStatus::Idle: return "нет приказа";
    case Ai::MoveStatus::Waiting: return "расчёт пути";
    case Ai::MoveStatus::Moving: return "в пути";
    case Ai::MoveStatus::Arrived: return "на месте";
    case Ai::MoveStatus::Unreachable: return "цель недоступна";
    case Ai::MoveStatus::Stuck: return "застрял";
    case Ai::MoveStatus::Unavailable: return "недоступно";
    }
    return "?";
}
Ai::MachinePtr BuildCorridorGuardMachine() {
    Ai::MachineBuilder machine("CorridorGuard");
    auto& patrol=machine.State("Patrol");
    patrol.Task<Ai::Tasks::FollowRoute>(0.35f).GoTo("Pause").OnSucceeded();
    patrol.GoTo("Chase").If(Ai::Conditions::CanSee(Target));
    auto& pause=machine.State("Pause");
    pause.Task<Ai::Tasks::Wait>(0.65f).GoTo("Patrol").OnSucceeded();
    pause.GoTo("Chase").If(Ai::Conditions::CanSee(Target));
    auto& chase=machine.State("Chase");
    chase.Task<Ai::Tasks::MoveTo>(Target,1.0f).GoTo("Patrol").OnFailed();
    chase.GoTo("Patrol").If(Ai::Not(Ai::Conditions::CanSee(Target)));
    return machine.Build();
}
ENGINE_AI_MACHINE("CorridorGuard",BuildCorridorGuardMachine)
}

void CorridorSoldier::BeginPlay() {
    Character::BeginPlay();
    Ai::Get(*GetGame()).AddTarget(*this,Ai::Team{1});
}

void CorridorGuard::SetupAi(Ai::Controller& ai) {
    AiCharacter::SetupAi(ai);
    const glm::vec3 home=GetWorldPosition();
    ai.SetRoute({home+glm::vec3(2.6f,0,0),home+glm::vec3(-2.6f,0,0)});
    ai.GetPerception().SetTeam(Ai::Team{2});
    ai.GetPerception().EnableSight(12.0f,360.0f,3.0f);
    ai.GetPerception().WriteTargetTo(Target);
    ai.Run(Ai::GetMachine("CorridorGuard"));
}

void ProjectGame::AfterInitialize() { Game::AfterInitialize(); EnsureCorridor(); }

void ProjectGame::EnsureCorridor() {
    if(built_)return;
    SetSimulationTimeScale(1.0f);
    GetSettings().Physics().SetGravity(glm::vec3(0));
    GetSettings().SetRenderingType(Forward);
    SetDirectionalLight({-0.45f,-1.0f,-0.35f},{1.0f,0.96f,0.9f},1.2f);
    SetShadowSettings(false,120.0f);
    BuildCorridor();
    built_=true;
    ApplyTacticalCamera();
}

void ProjectGame::ApplyTacticalCamera() {
    auto* camera=GetPlayer(); if(!camera)return;
    camera->SetCameraMode(CameraMode::Free);
    camera->SetProjection(true,60.0f,0.1f,100.0f,22.0f);
    camera->SetPosition({0.0f,20.0f,4.0f});
    camera->SetViewDirection({0.0f,-1.0f,0.0f},{0.0f,0.0f,1.0f});
    camera->StopRotate(true,true);
    camera->EnableWASD(false);
    camera->RefreshMatrices();
}

void ProjectGame::InitializeNavigation() {
    RebuildNavigationForCrate(true);
    navigationReady_=true;
}

void ProjectGame::RebuildNavigationForCrate(bool force) {
    if(!crate_)return;
    const glm::vec3 cratePosition=crate_->GetWorldPosition();
    auto& grid=Ai::Get(*this).Navigation();
    if(!force&&grid.IsConfigured()&&hasCrateNavCells_) {
        const auto minimum=grid.CellOf({cratePosition.x-0.9f,cratePosition.z-0.7f});
        const auto maximum=grid.CellOf({cratePosition.x+0.9f,cratePosition.z+0.7f});
        if(minimum.x==lastCrateNavMin_.x&&minimum.y==lastCrateNavMin_.y&&maximum.x==lastCrateNavMax_.x&&maximum.y==lastCrateNavMax_.y)return;
    }
    grid.SetBounds({-3.0f,-10.8f},{3.0f,10.8f},0.25f);
    // The two side panels and the box seal the only passage until the box is pushed forward.
    grid.BlockBox({-3.0f,1.1f},{-1.0f,2.9f});
    grid.BlockBox({1.0f,1.1f},{3.0f,2.9f});
    // A real service cabinet in the middle of the corridor requires a detour.
    grid.BlockBox({-1.2f,-2.35f},{1.2f,-1.65f});
    // A low bumper holds the crate after it has left the gate.
    grid.BlockBox({-0.95f,6.2f},{0.95f,6.8f});
    grid.BlockBox({cratePosition.x-0.9f,cratePosition.z-0.7f},{cratePosition.x+0.9f,cratePosition.z+0.7f});
    lastCrateNavMin_=grid.CellOf({cratePosition.x-0.9f,cratePosition.z-0.7f});
    lastCrateNavMax_=grid.CellOf({cratePosition.x+0.9f,cratePosition.z+0.7f});
    hasCrateNavCells_=true;
    gateOpen_=grid.Connected({0.0f,-0.3f},{0.0f,3.4f},0.4f);
}

void ProjectGame::InitializeUnitGroups() {
    if(navigationReady_==false||squad_.empty())return;
    auto& world=Ai::Get(*this);
    for(size_t i=0;i<squad_.size();++i) {
        auto& group=world.CreateGroup("Player squad "+std::to_string(i+1));
        group.GetPerception().SetTeam(Ai::Team{1});
        group.SetFacing(0.0f);
        group.SetFormation({0.9f,1});
        group.AddCharacter(*squad_[i].unit,0.4f);
        squad_[i].group=&group;
        squad_[i].groupMemberIndex=0;
    }
    if(!squad_.empty())squad_[0].selected=true;
    for(auto& soldier:squad_) {
        soldier.mesh->SetColor(soldier.selected?glm::vec4(1.0f,0.78f,0.18f,1.0f):glm::vec4(0.22f,0.55f,0.98f,1.0f));
        soldier.orderMarker->SetColor(soldier.selected?glm::vec4(1.0f,0.78f,0.18f,1.0f):glm::vec4(0.18f,0.52f,0.56f,1.0f));
        soldier.orderMarker->SetScale(soldier.selected?glm::vec3(0.72f,0.12f,0.72f):glm::vec3(0.42f,0.08f,0.42f));
        if(soldier.selected)soldier.orderMarker->SetPosition(soldier.unit->GetWorldPosition()+glm::vec3(0,1.35f,0));
    }
}

void ProjectGame::SelectUnit(int index,bool additive) {
    if(index<0||index>=static_cast<int>(squad_.size()))return;
    if(!additive)for(auto& unit:squad_)unit.selected=false;
    if(additive&&squad_[index].selected&&std::count_if(squad_.begin(),squad_.end(),[](const SquadVisual& unit){return unit.selected;})>1)
        squad_[index].selected=false;
    else squad_[index].selected=true;
    focused_=index;
    for(auto& soldier:squad_) {
        soldier.mesh->SetColor(soldier.selected?glm::vec4(1.0f,0.78f,0.18f,1.0f):glm::vec4(0.22f,0.55f,0.98f,1.0f));
        soldier.orderMarker->SetColor(soldier.selected?glm::vec4(1.0f,0.78f,0.18f,1.0f):glm::vec4(0.18f,0.52f,0.56f,1.0f));
        soldier.orderMarker->SetScale(soldier.selected?glm::vec3(0.72f,0.12f,0.72f):glm::vec3(0.42f,0.08f,0.42f));
        soldier.orderMarker->SetPosition(soldier.selected?soldier.unit->GetWorldPosition()+glm::vec3(0,1.35f,0):
            (soldier.hasOrder?soldier.orderTarget: soldier.unit->GetWorldPosition()+glm::vec3(0,-1.0f,0)));
    }
}

Ai::Group* ProjectGame::GroupForSelection() {
    std::vector<size_t> selected;
    for(size_t i=0;i<squad_.size();++i)if(squad_[i].selected)selected.push_back(i);
    if(selected.empty())return nullptr;
    Ai::Group* existing=squad_[selected.front()].group;
    bool reusable=existing!=nullptr;
    for(size_t i:selected)reusable=reusable&&squad_[i].group==existing;
    if(reusable&&existing->Size()==selected.size())return existing;

    auto& world=Ai::Get(*this);
    std::vector<Ai::Group*> emptied;
    for(size_t i:selected) {
        auto& soldier=squad_[i];
        Ai::Group* old=soldier.group;
        if(old) {
            old->RemoveMember(soldier.groupMemberIndex);
            if(old->Size()==0&&std::find(emptied.begin(),emptied.end(),old)==emptied.end())emptied.push_back(old);
        }
        soldier.group=nullptr;
    }
    for(Ai::Group* group:emptied)world.Destroy(*group);

    auto& group=world.CreateGroup("Player order "+std::to_string(world.Frame()));
    group.GetPerception().SetTeam(Ai::Team{1});
    group.SetFacing(selected.size()>1?1.5707963f:0.0f);
    group.SetFormation({0.9f,1});
    for(size_t i:selected) {
        auto& soldier=squad_[i];
        soldier.groupMemberIndex=group.Members().size();
        group.AddCharacter(*soldier.unit,0.4f);
        soldier.group=&group;
    }
    return &group;
}

void ProjectGame::IssueGroupOrder(const glm::vec3& target) {
    Ai::Group* group=GroupForSelection();
    if(!group)return;
    // A file fits the narrow passage; on the near side, a line gives the squad clear spacing around the cabinet.
    if(target.z>3.0f) { group->SetFacing(0.0f); group->SetFormation({0.9f,1}); }
    else { group->SetFacing(0.0f); group->SetFormation({0.9f,3}); }
    lastIssuedGroup_=group;
    lastIssuedTarget_=target;
    ++acceptedOrderCount_;
    group->MoveTo(target,0.55f);
    lastOrderStatus_=group->GetMoveStatus();
    const auto& members=group->Members();
    for(auto& soldier:squad_) {
        if(!soldier.selected||soldier.group!=group)continue;
        soldier.hasOrder=true;
        if(soldier.groupMemberIndex<members.size()) {
            const auto& slot=members[soldier.groupMemberIndex].slot;
            soldier.orderTarget={slot.x,soldier.unit->GetWorldPosition().y,slot.y};
            soldier.orderMarker->SetPosition({slot.x,-0.23f,slot.y});
        } else {
            soldier.orderTarget=target;
            soldier.orderMarker->SetPosition({target.x,-0.23f,target.z});
        }
    }
}

void ProjectGame::AddBox(const std::string& name,glm::vec3 pos,glm::vec3 scale,glm::vec4 color,PhysicsBodyType type,float restitution,uint32_t traceChannels) {
    auto cube=std::make_unique<CubeComponent>(pos,glm::vec3(0),scale,color);
    cube->SetPhysicsEnabled(true); cube->SetPhysicsBodyType(type); cube->SetPhysicsShapeType(PhysicsShapeType::Box);
    cube->SetPhysicsFriction(0.8f); cube->SetPhysicsRestitution(restitution);
    cube->traceChannels=traceChannels;
    auto* raw=cube.get();
    if(RegisterComponent(name,raw)!=RegisterResult::Ok)throw std::runtime_error("Cannot add "+name);
    cube.release();
}

void ProjectGame::BuildCorridor() {
    auto light=std::make_unique<PointLightComponent>(glm::vec3(0,6,1),glm::vec3(1.0f,0.88f,0.72f),1.25f,32.0f);
    light->SetCastShadows(false);
    auto* lightRaw=light.get();
    if(RegisterComponent("HallLight",lightRaw)!=RegisterResult::Ok)throw std::runtime_error("Cannot add HallLight");
    light.release();
    AddBox("Floor",{0,-0.55f,0},{7,0.5f,22},{0.26f,0.30f,0.27f,1},PhysicsBodyType::Static,0.15f,FloorTraceChannel);
    AddBox("WallLeft",{-3.4f,1,0},{0.35f,2.5f,22},{0.42f,0.46f,0.43f,1},PhysicsBodyType::Static);
    AddBox("WallRight",{3.4f,1,0},{0.35f,2.5f,22},{0.42f,0.46f,0.43f,1},PhysicsBodyType::Static);
    AddBox("GateLeft",{-2.0f,0.45f,2.0f},{2.0f,1.8f,1.8f},{0.48f,0.52f,0.54f,1},PhysicsBodyType::Static,0.0f);
    AddBox("GateRight",{2.0f,0.45f,2.0f},{2.0f,1.8f,1.8f},{0.48f,0.52f,0.54f,1},PhysicsBodyType::Static,0.0f);
    AddBox("CrateStop",{0,0.45f,6.5f},{1.9f,1.8f,0.6f},{0.48f,0.52f,0.54f,1},PhysicsBodyType::Static,0.0f);
    AddBox("ServiceBarrier",{0,0.55f,-2.0f},{2.4f,1.9f,0.7f},{0.52f,0.40f,0.31f,1},PhysicsBodyType::Static,0.0f);
    AddBox("ExitMarker",{0,0.05f,9.5f},{2,0.1f,0.2f},{0.2f,0.9f,0.45f,1},PhysicsBodyType::Static);
    auto crate=std::make_unique<CubeComponent>(glm::vec3(0,0.7f,2),glm::vec3(0),glm::vec3(1.8f,1.4f,1.4f),glm::vec4(0.95f,0.52f,0.14f,1));
    crate->SetPhysicsEnabled(true); crate->SetPhysicsBodyType(PhysicsBodyType::Dynamic); crate->SetPhysicsShapeType(PhysicsShapeType::Box);
    crate->SetPhysicsDensity(12.0f); crate->SetPhysicsFriction(0.8f); crate->SetPhysicsRestitution(0.0f);
    crate_=crate.get();
    if(RegisterComponent("SupplyCrate",crate_)!=RegisterResult::Ok)throw std::runtime_error("Cannot add crate");
    crate.release();
    const float offsets[3]={-1.5f,0,1.5f}; const glm::vec4 blue(0.22f,0.55f,0.98f,1);
    for(int i=0;i<3;++i) {
        auto unit=std::make_unique<CorridorSoldier>(); unit->SetPosition({offsets[i],0.65f,-6}); unit->SetMoveSpeed(3.0f);
        auto* body=unit.get();
        if(RegisterComponent("Squad"+std::to_string(i+1),body)!=RegisterResult::Ok)throw std::runtime_error("Cannot add squad unit");
        unit.release();
        auto visual=std::make_unique<CubeComponent>(glm::vec3(offsets[i],0.65f,-6),glm::vec3(0),glm::vec3(0.62f,1.1f,0.45f),blue);
        auto* mesh=visual.get();
        if(RegisterComponent("SquadVisual"+std::to_string(i+1),mesh)!=RegisterResult::Ok)throw std::runtime_error("Cannot add soldier visual");
        mesh->traceChannels=UnitTraceChannel;
        visual.release();
        auto marker=std::make_unique<CubeComponent>(glm::vec3(offsets[i],-0.35f,-6),glm::vec3(0),glm::vec3(0.42f,0.08f,0.42f),glm::vec4(0.15f,0.92f,0.78f,1));
        auto* markerRaw=marker.get();
        if(RegisterComponent("OrderMarker"+std::to_string(i+1),markerRaw)!=RegisterResult::Ok)throw std::runtime_error("Cannot add order marker");
        marker.release();
        squad_.push_back({body,mesh,markerRaw});
    }
    auto guard=std::make_unique<CorridorGuard>(); guard->SetPosition({0,0.65f,6}); guard->team=2; guard->SetMoveSpeed(1.6f); guard->stateMachine="CorridorGuard";
    auto* guardBody=guard.get();
    if(RegisterComponent("CorridorGuard",guardBody)!=RegisterResult::Ok)throw std::runtime_error("Cannot add guard");
    guard.release();
    auto guardVisual=std::make_unique<CubeComponent>(glm::vec3(0,0.65f,6),glm::vec3(0),glm::vec3(0.8f,1.2f,0.55f),glm::vec4(0.94f,0.22f,0.18f,1));
    auto* guardMesh=guardVisual.get();
    if(RegisterComponent("GuardVisual",guardMesh)!=RegisterResult::Ok)throw std::runtime_error("Cannot add guard visual");
    guardVisual.release(); guards_.push_back({guardBody,guardMesh});
    auto ui=std::make_unique<UIComponent>(); FontAtlasSettings font; font.Face=L"Consolas"; font.PixelHeight=14; ui->SetFont(font);
    UIRect panel; panel.X=10; panel.Y=10; panel.Width=230; panel.Height=160;
    auto* interactivePanel=ui->AddPanel(panel,{0.03f,0.06f,0.09f,0.9f});
    interactivePanel->bInteractive=true;
    UIRect text; text.X=19; text.Y=17; text.Width=200; text.Height=20;
    auto* title=ui->AddLabel(text,"РЕМОНТНЫЙ КОРИДОР",{0.98f,0.84f,0.52f,1}); title->Name="title";
    text.Y=40; hudGoal_=ui->AddLabel(text,"Проход: ЗАКРЫТ",{0.92f,0.96f,1,1}); hudGoal_->Name="goal";
    text.Y=62; hudFsm_=ui->AddLabel(text,"FSM: Patrol",{1.0f,0.5f,0.42f,1}); hudFsm_->Name="fsm";
    text.Y=84; hudSelected_=ui->AddLabel(text,"Выбрано: 1/3",{0.68f,0.84f,1,1}); hudSelected_->Name="selected";
    text.Y=106; hudControls_=ui->AddLabel(text,"ЛКМ/Shift: выбор",{0.68f,0.84f,1,1}); hudControls_->Name="controls";
    text.Y=126; hudHelp_=ui->AddLabel(text,"ПКМ: группа | E: груз",{0.68f,0.84f,1,1}); hudHelp_->Name="help";
    text.Y=146; hudOrder_=ui->AddLabel(text,"Приказ: —",{0.15f,0.92f,0.78f,1}); hudOrder_->Name="order";
    hud_=ui.get(); const auto shader=EnginePaths::Shader("UI.hlsl").generic_u8string();
    if(RegisterComponent("TacticalHud",hud_,shader,shader)!=RegisterResult::Ok)throw std::runtime_error("Cannot add HUD");
    ui.release();
}

void ProjectGame::PreUpdate(float dt) {
    EnsureCorridor();
    Game::PreUpdate(dt);
    if(!navigationReady_) {
        // AI::World attaches after the scene enters Play and resets its grid in OnSceneReady.
        InitializeNavigation();
        navigationReady_=true;
        InitializeUnitGroups();
    }
    ApplyTacticalCamera();
    auto& input=GetInput();
    pointerBlocked_=input.IsPointerBlocked();
    const bool one=input.IsPhysicalKeyDown(Keys::D1),two=input.IsPhysicalKeyDown(Keys::D2),three=input.IsPhysicalKeyDown(Keys::D3);
    const bool breach=input.IsPhysicalKeyDown(Keys::E);
    const bool left=input.IsPhysicalKeyDown(Keys::LeftButton),right=input.IsPhysicalKeyDown(Keys::RightButton);
    const bool shift=input.IsPhysicalKeyDown(Keys::Shift);
    if(one&&!keys_[0])SelectUnit(0,false);
    if(two&&!keys_[1])SelectUnit(1,false);
    if(three&&!keys_[2])SelectUnit(2,false);
    if(breach&&!keys_[3]&&crate_)impulsePending_=true;
    if(impulsePending_&&crate_&&crate_->HasPhysicsBody()) {
        crate_->AddPhysicsImpulse({0.0f,3.0f,150.0f});
        impulsePending_=false;
    }
    if(left&&!keys_[4]) {
        Trace::Query query; query.channels=UnitTraceChannel; query.geometry=Trace::Geometry::Bounds;
        auto result=RaycastCursor(query);
        lastTraceStatus_=Trace::StatusName(result.status);
        if(result&&result.hit) {
            int index=-1;
            for(size_t i=0;i<squad_.size();++i)if(squad_[i].mesh->GetComponentId()==result.hit->componentId)index=static_cast<int>(i);
            if(index>=0)SelectUnit(index,shift);
        }
    }
    if(right&&!keys_[5]) {
        Trace::Query query;
        query.channels=FloorTraceChannel;
        query.geometry=Trace::Geometry::Bounds;
        auto result=RaycastCursor(query);
        lastTraceStatus_=Trace::StatusName(result.status);
        if(result&&result.hit&&!won_&&!lost_) {
            IssueGroupOrder({result.hit->position.x,0.65f,result.hit->position.z});
        }
    }
    keys_[0]=one; keys_[1]=two; keys_[2]=three; keys_[3]=breach;
    keys_[4]=left; keys_[5]=right; keys_[6]=shift;
    RebuildNavigationForCrate(false);
    bool barrierViolation=false;
    ++simulationFrames_;
    for(size_t i=0;i<squad_.size();++i) {
        auto& item=squad_[i];
        const auto pos=item.unit->GetWorldPosition();
        // Exact circle-vs-rectangle clearance for the soldier's 0.4m radius.
        const float dx=std::max(std::abs(pos.x)-1.2f,0.0f);
        const float dz=std::max(std::abs(pos.z+2.0f)-0.35f,0.0f);
        if((dx*dx+dz*dz)<0.16f) {
            barrierViolation=true;
            if(!firstBarrierViolationFrame_) {
                firstBarrierViolationFrame_=simulationFrames_;
                firstBarrierViolationPosition_=pos;
                firstBarrierViolationUnit_=static_cast<int>(i+1);
            }
        }
        item.mesh->SetPosition(pos+glm::vec3(0,0.1f,0));
    }
    if(barrierViolation)++barrierViolationFrames_;
    for(auto& item:squad_) {
        if(item.selected)item.orderMarker->SetPosition(item.unit->GetWorldPosition()+glm::vec3(0,1.35f,0));
        else if(item.hasOrder)item.orderMarker->SetPosition(item.orderTarget);
        else item.orderMarker->SetPosition(item.unit->GetWorldPosition()+glm::vec3(0,-1.0f,0));
    }
    for(auto& item:guards_)item.mesh->SetPosition(item.unit->GetWorldPosition()+glm::vec3(0,0.1f,0));
    if(!won_&&!lost_)for(auto& item:squad_) {
        if(glm::length(item.unit->GetWorldPosition()-guards_[0].unit->GetWorldPosition())<1.05f)lost_=true;
        if(gateOpen_&&item.unit->GetWorldPosition().z>9.0f)won_=true;
    }
    if(lastIssuedGroup_)lastOrderStatus_=lastIssuedGroup_->GetMoveStatus();
    UpdateHud();
}

void ProjectGame::UpdateHud() {
    if(!hud_)return;
    const std::string status=won_?"ПОБЕДА":lost_?"ПОРАЖЕНИЕ":(gateOpen_?"Проход: ОТКРЫТ":"Проход: ЗАКРЫТ");
    if(hudGoal_)hudGoal_->SetText(status);
    const std::string state=!guards_.empty()&&guards_[0].unit->GetAi()?guards_[0].unit->GetAi()->ActiveState():"ожидает Play";
    if(hudFsm_)hudFsm_->SetText("Охранник FSM: "+state);
    const auto selectedCount=std::count_if(squad_.begin(),squad_.end(),[](const SquadVisual& unit){return unit.selected;});
    if(hudSelected_)hudSelected_->SetText("Группа: "+std::to_string(selectedCount)+"/3 (фокус "+std::to_string(focused_+1)+")");
    if(hudControls_)hudControls_->SetText("ЛКМ выбор | Shift+ЛКМ +");
    if(hudHelp_)hudHelp_->SetText("ПКМ приказ | E груз");
    if(hudOrder_) {
        if(lastIssuedGroup_)hudOrder_->SetText("Маршрут: "+std::string(MoveStatusText(lastIssuedGroup_->GetMoveStatus())));
        else hudOrder_->SetText("Маршрут: —");
    }
    if(const char* path=std::getenv("PAINENGINE_STRATEGY_TELEMETRY")) {
        if(++telemetryFrames_%30==0&&!squad_.empty()&&!guards_.empty()) {
            const auto p=squad_[focused_].unit->GetWorldPosition(); const auto c=crate_->GetWorldPosition(); const auto g=guards_[0].unit->GetWorldPosition();
            int connectedUnits=0;
            if(navigationReady_)for(const auto& soldier:squad_)if(soldier.selected) {
                const auto unit=soldier.unit->GetWorldPosition();
                connectedUnits+=Ai::Get(*this).Navigation().Connected({unit.x,unit.z},{lastIssuedTarget_.x,lastIssuedTarget_.z},0.4f)?1:0;
            }
            std::ofstream out(path,std::ios::app);
            if(out) out<<"focused="<<focused_+1<<" selectedCount="<<selectedCount<<" unit="<<p.x<<","<<p.y<<","<<p.z<<" crate="<<c.x<<","<<c.y<<","<<c.z
                <<" navConfigured="<<(navigationReady_?Ai::Get(*this).Navigation().IsConfigured():false)
                <<" navSize="<<(navigationReady_?Ai::Get(*this).Navigation().Width():0)<<"x"<<(navigationReady_?Ai::Get(*this).Navigation().Height():0)
                <<" navVersion="<<(navigationReady_?Ai::Get(*this).Navigation().Version():0)<<" navConnectedSelected="<<connectedUnits
                <<" acceptedOrders="<<acceptedOrderCount_<<" orderStatus="<<MoveStatusText(lastOrderStatus_)
                <<" orderTarget="<<lastIssuedTarget_.x<<","<<lastIssuedTarget_.z
                <<" gateOpen="<<gateOpen_<<" barrierViolationFrames="<<barrierViolationFrames_
                <<" firstBarrierViolation="<<firstBarrierViolationFrame_<<":"<<firstBarrierViolationUnit_<<":"
                <<firstBarrierViolationPosition_.x<<","<<firstBarrierViolationPosition_.z
                <<" guard="<<g.x<<","<<g.y<<","<<g.z<<" state="<<state<<" won="<<won_<<" lost="<<lost_<<" paused=false"
                <<" pointerBlocked="<<pointerBlocked_<<" trace="<<lastTraceStatus_;
            if(out) for(size_t i=0;i<squad_.size();++i) {
                const auto unit=squad_[i].unit->GetWorldPosition(); const auto& order=squad_[i];
                out<<" squad"<<i+1<<"="<<unit.x<<","<<unit.z<<" selected="<<order.selected<<" group="<<(order.group?order.group->Serial():0)
                   <<" target="<<(order.hasOrder?1:0)<<":"<<order.orderTarget.x<<","<<order.orderTarget.z;
            }
            if(out) out<<"\n";
        }
    }
}
void ProjectGame::TickComponents(float dt) { Game::TickComponents(dt); }
