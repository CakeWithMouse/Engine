#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/AI/AiCharacter.h>
#include <Engine/AI/Group.h>
#include <array>
#include <limits>
#include <vector>

class CorridorSoldier final : public Character {
public:
    void BeginPlay() override;
};
class CorridorGuard final : public AiCharacter {
protected:
    void SetupAi(Ai::Controller& ai) override;
};

ENGINE_GAME("ProjectGame")
class ProjectGame final : public Game {
public:
    void AfterInitialize() override;
    void PreUpdate(float deltaTime) override;
    void TickComponents(float deltaTime) override;
private:
    struct SquadVisual {
        CorridorSoldier* unit=nullptr;
        CubeComponent* mesh=nullptr;
        CubeComponent* orderMarker=nullptr;
        Ai::Group* group=nullptr;
        size_t groupMemberIndex=0;
        glm::vec3 orderTarget{0};
        bool selected=false, hasOrder=false;
    };
    struct GuardVisual { AiCharacter* unit=nullptr; CubeComponent* mesh=nullptr; };
    std::vector<SquadVisual> squad_;
    std::vector<GuardVisual> guards_;
    CubeComponent* crate_=nullptr;
    UIComponent* hud_=nullptr;
    UILabel* hudGoal_=nullptr;
    UILabel* hudFsm_=nullptr;
    UILabel* hudControls_=nullptr;
    UILabel* hudHelp_=nullptr;
    UILabel* hudSelected_=nullptr;
    UILabel* hudOrder_=nullptr;
    int focused_=0;
    uint32_t telemetryFrames_=0;
    uint32_t acceptedOrderCount_=0;
    uint64_t barrierViolationFrames_=0;
    std::string lastTraceStatus_="NotRequested";
    Ai::MoveStatus lastOrderStatus_=Ai::MoveStatus::Idle;
    Ai::Group* lastIssuedGroup_=nullptr;
    glm::vec3 lastIssuedTarget_{0};
    uint64_t simulationFrames_=0, firstBarrierViolationFrame_=0;
    glm::vec3 firstBarrierViolationPosition_{0};
    int firstBarrierViolationUnit_=0;
    bool pointerBlocked_=false;
    bool keys_[7]{};
    bool won_=false, lost_=false, built_=false, impulsePending_=false, navigationReady_=false;
    glm::ivec2 lastCrateNavMin_{0}, lastCrateNavMax_{0};
    bool hasCrateNavCells_=false, gateOpen_=false;
    void EnsureCorridor();
    void BuildCorridor();
    void InitializeNavigation();
    void RebuildNavigationForCrate(bool force);
    void InitializeUnitGroups();
    void SelectUnit(int index,bool additive);
    Ai::Group* GroupForSelection();
    void IssueGroupOrder(const glm::vec3& target);
    void ApplyTacticalCamera();
    void AddBox(const std::string& name, glm::vec3 pos, glm::vec3 scale, glm::vec4 color, PhysicsBodyType type, float restitution=0.15f, uint32_t traceChannels=Trace::DefaultChannel);
    void UpdateHud();
};

