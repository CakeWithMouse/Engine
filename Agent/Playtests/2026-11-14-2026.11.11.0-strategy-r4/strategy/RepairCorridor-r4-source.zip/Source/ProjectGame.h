#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/AI/AiCharacter.h>
#include <Engine/AI/Group.h>
#include <Engine/InputDevice/InputActions.h>
#include <array>
#include <limits>
#include <vector>

class CorridorSoldier final : public Character {
public:
    void BeginPlay() override;
};
class CorridorGuard final : public AiCharacter {
protected:
    void SetupAi(Ai::Controller& ai) override;
};

ENGINE_GAME("ProjectGame")
class ProjectGame final : public Game {
public:
    void AfterInitialize() override;
    void PreUpdate(float deltaTime) override;
    void TickComponents(float deltaTime) override;
private:
    struct SquadVisual {
        CorridorSoldier* unit=nullptr;
        CubeComponent* mesh=nullptr;
        CubeComponent* orderMarker=nullptr;
        Ai::Group* group=nullptr;
        size_t groupMemberIndex=0;
        glm::vec3 orderTarget{0};
        bool selected=false, hasOrder=false;
    };
    struct GuardVisual { AiCharacter* unit=nullptr; CubeComponent* mesh=nullptr; };
    struct AttackOrder { uint32_t groupSerial=0; Ai::ObjectRef target{}; float cooldown=0.0f; };
    std::vector<SquadVisual> squad_;
    std::vector<GuardVisual> guards_;
    std::vector<AttackOrder> attackOrders_;
    CubeComponent* crate_=nullptr;
    UIComponent* hud_=nullptr;
    UILabel* hudGoal_=nullptr;
    UILabel* hudFsm_=nullptr;
    UILabel* hudControls_=nullptr;
    UILabel* hudHelp_=nullptr;
    UILabel* hudCommand_=nullptr;
    UILabel* hudSelected_=nullptr;
    UILabel* hudOrder_=nullptr;
    UILabel* hudCombat_=nullptr;
    std::array<UIPanel*,4> selectionFrame_{};
    int focused_=0;
    uint32_t telemetryFrames_=0;
    uint32_t acceptedOrderCount_=0;
    uint32_t attackHits_=0, attackOrdersIssued_=0, cancelledDragCount_=0, selectionClickCount_=0;
    uint64_t selectionRectTests_=0;
    uint64_t barrierViolationFrames_=0;
    std::string lastTraceStatus_="NotRequested";
    Ai::MoveStatus lastOrderStatus_=Ai::MoveStatus::Idle;
    Ai::Group* lastIssuedGroup_=nullptr;
    glm::vec3 lastIssuedTarget_{0};
    uint64_t simulationFrames_=0, firstBarrierViolationFrame_=0;
    glm::vec3 firstBarrierViolationPosition_{0};
    int firstBarrierViolationUnit_=0;
    bool pointerBlocked_=false, inputBound_=false, dragActive_=false, dragMoved_=false, dragShift_=false;
    bool guardDead_=false, damageHandlerBound_=false;
    glm::vec2 dragStart_{0}, dragCurrent_{0};
    glm::vec3 guardLastPosition_{0};
    int guardHealth_=4;
    float guardFlash_=0.0f;
    bool keys_[7]{};
    bool won_=false, lost_=false, built_=false, impulsePending_=false, navigationReady_=false;
    glm::ivec2 lastCrateNavMin_{0}, lastCrateNavMax_{0};
    bool hasCrateNavCells_=false, gateOpen_=false;
    void EnsureCorridor();
    void BindSelectionInput();
    void BeginSelectionDrag(const Input::Event& event);
    void UpdateSelectionDrag(const Input::Event& event);
    void EndSelectionDrag(const Input::Event& event);
    void CancelSelectionDrag();
    void UpdateSelectionFrame();
    void SelectAtCursor(bool additive);
    void SelectScreenRectangle(bool additive);
    void ApplySelection(const std::vector<int>& indexes, bool additive);
    void BuildCorridor();
    void InitializeNavigation();
    void RebuildNavigationForCrate(bool force);
    void InitializeUnitGroups();
    void SelectUnit(int index,bool additive);
    Ai::Group* GroupForSelection();
    void IssueGroupOrder(const glm::vec3& target);
    void IssueAttackOrder(Ai::Group* group, Ai::ObjectRef target);
    void UpdateCombat(float deltaTime);
    void HandleDamage(Ai::ObjectRef victim, Ai::ObjectRef instigator, float amount);
    void RemoveDeadGuard();
    void ApplyTacticalCamera();
    void AddBox(const std::string& name, glm::vec3 pos, glm::vec3 scale, glm::vec4 color, PhysicsBodyType type, float restitution=0.15f, uint32_t traceChannels=Trace::DefaultChannel);
    void UpdateHud();
    Input::Connection dragPressed_, dragHeld_, dragReleased_;
    Input::Scope inputScope_;
};

