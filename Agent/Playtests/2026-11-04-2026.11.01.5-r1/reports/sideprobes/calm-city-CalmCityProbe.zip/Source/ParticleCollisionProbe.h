#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/ParticleSystemComponent.h>

ENGINE_COMPONENT("Particle collision probe", "CalmCity.ParticleCollisionProbe")
class ParticleCollisionProbe : public ParticleSystemComponent
{
public:
    ParticleCollisionProbe();
};
