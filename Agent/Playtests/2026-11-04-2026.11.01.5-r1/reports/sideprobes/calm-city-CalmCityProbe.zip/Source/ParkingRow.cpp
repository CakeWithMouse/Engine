#include "ParkingRow.h"
#include <Engine/Render/MeshPrimitives.h>
#include <cmath>

MeshLodData ParkingRow::VehicleMesh()
{
    MeshLodData result;
    auto appendBox = [&](const glm::vec3& size, const glm::vec3& center) {
        auto box = MeshPrimitives::Cube();
        const auto base = static_cast<uint32_t>(result.Vertices.size());
        for (auto vertex : box.Vertices) {
            vertex.Position.x = vertex.Position.x * size.x + center.x;
            vertex.Position.y = vertex.Position.y * size.y + center.y;
            vertex.Position.z = vertex.Position.z * size.z + center.z;
            float nx = vertex.Normal.x / size.x;
            float ny = vertex.Normal.y / size.y;
            float nz = vertex.Normal.z / size.z;
            const float length = std::sqrt(nx * nx + ny * ny + nz * nz);
            vertex.Normal = {nx / length, ny / length, nz / length, 0.0f};
            result.Vertices.push_back(vertex);
        }
        for (const auto index : box.Indices)
            result.Indices.push_back(base + index);
    };
    appendBox({1.7f, 0.7f, 2.6f}, {0.0f, 0.35f, 0.0f});
    appendBox({1.15f, 0.48f, 1.2f}, {0.0f, 0.88f, -0.08f});

    const auto wheel = MeshPrimitives::Cylinder(0.23f, 0.16f, 20);
    for (const float x : {-0.78f, 0.78f}) {
        for (const float z : {-0.82f, 0.82f}) {
            const auto base = static_cast<uint32_t>(result.Vertices.size());
            for (auto vertex : wheel.Vertices) {
                const float oldX = vertex.Position.x;
                const float oldY = vertex.Position.y;
                vertex.Position.x = -oldY + x;
                vertex.Position.y = oldX + 0.25f;
                vertex.Position.z += z;
                const float normalX = -vertex.Normal.y;
                const float normalY = vertex.Normal.x;
                vertex.Normal.x = normalX;
                vertex.Normal.y = normalY;
                result.Vertices.push_back(vertex);
            }
            for (const auto index : wheel.Indices)
                result.Indices.push_back(base + index);
        }
    }
    return result;
}

ParkingRow::ParkingRow()
{
    SetLod(0, VehicleMesh());
    SetAutoLod({0.55f, 0.25f});
    SetLodScreenHeights({100.0f, 42.0f});
    SetLodDebugColors(true);
    SetAssetValidation(true, "parking-block");
    SetShadowLodBias(1);
    SetDrawDistance(90.0f);
    ReserveInstances(9);

    const glm::vec4 colors[] = {
        {0.85f,0.24f,0.18f,1}, {0.12f,0.55f,0.82f,1}, {0.95f,0.66f,0.16f,1},
        {0.24f,0.72f,0.42f,1}, {0.68f,0.38f,0.82f,1}, {0.85f,0.82f,0.72f,1},
        {0.16f,0.72f,0.72f,1}, {0.92f,0.42f,0.63f,1}, {0.66f,0.72f,0.28f,1}
    };
    for (int row = 0; row < 3; ++row) {
        for (int column = 0; column < 3; ++column) {
            MeshInstance instance;
            instance.Position = {-4.0f + 4.0f * column, 0.0f, -3.0f + 3.0f * row};
            instance.Scale = 1.0f;
            instance.Color = colors[row * 3 + column];
            instance.Yaw = float(row * 3 + column) * 0.12f;
            AddInstance(instance);
        }
    }
}
