#include "ProjectGame.h"
#include "ParkingRow.h"
#include "ParticleCollisionProbe.h"
#include <Engine/Render/MeshValidation.h>
#include <Engine/Render/MeshSimplifier.h>
#include <iostream>
#include <stdexcept>

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    SetSimulationTimeScale(1.0f);
    auto& settings = GetSettings();
    settings.SetVSync(false);
    settings.SetRenderingType(Forward);
    settings.SetAntialiasing(1);

    const auto mesh = ParkingRow::VehicleMesh();
    const auto validation = ValidateMesh(mesh);
    std::cout << validation.ToText("parking-block") << std::endl;
    MeshSimplifySettings simplifySettings;
    simplifySettings.TargetRatio = 0.55f;
    MeshSimplifyResult simplifyResult;
    const auto simplified = SimplifyMesh(mesh, simplifySettings, &simplifyResult);
    std::cout << "Parking simplify: source=" << simplifyResult.SourceTriangles
              << " result=" << simplifyResult.ResultTriangles
              << " usable=" << (!simplified.Vertices.empty()) << std::endl;

    auto& scene = GetScene();
    bool hasRow = false;
    bool hasParticles = false;
    for (const auto& entry : scene.GetComponents()) {
        hasRow = hasRow || dynamic_cast<ParkingRow*>(entry.second.get()) != nullptr;
        hasParticles = hasParticles || dynamic_cast<ParticleCollisionProbe*>(entry.second.get()) != nullptr;
    }
    if (!hasRow) {
        std::unique_ptr<GameComponent> row = std::make_unique<ParkingRow>();
        const auto added = scene.AddComponent("Parking row", row, "CalmCity.ParkingRow");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the parking row");
    }
    if (!hasParticles) {
        std::unique_ptr<GameComponent> particles = std::make_unique<ParticleCollisionProbe>();
        const auto added = scene.AddComponent("Depth-collision particles", particles, "CalmCity.ParticleCollisionProbe");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the particle collision probe");
    }
}

void ProjectGame::PreUpdate(float deltaTime) { Game::PreUpdate(deltaTime); }
void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }
