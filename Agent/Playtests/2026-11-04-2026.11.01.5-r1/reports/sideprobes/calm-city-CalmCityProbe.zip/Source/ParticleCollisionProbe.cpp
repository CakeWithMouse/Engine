#include "ParticleCollisionProbe.h"

ParticleCollisionProbe::ParticleCollisionProbe()
    : ParticleSystemComponent({-2.0f, 0.8f, 0.0f}, {}, {1.0f, 1.0f, 1.0f}, {1.0f, 0.35f, 0.12f, 1.0f})
{
    SetParticleCount(128);
    SetBaseLifetime(1.4f);
    SetSpreadRadius(0.15f);
    SetBaseVelocity({0.0f, 0.8f, 2.0f});
    SetAcceleration({0.0f, -1.8f, 0.0f});
    SetDepthCollision(true);
    SetDepthCollisionResponse(0.06f, 0.35f, 0.2f);
    SetSortingEnabled(true);
    SetSimulationRate(1.0f);
}
