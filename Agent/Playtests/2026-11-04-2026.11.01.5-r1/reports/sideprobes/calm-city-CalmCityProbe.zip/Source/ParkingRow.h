#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/InstancedMeshComponent.h>

ENGINE_COMPONENT("Parking row", "CalmCity.ParkingRow")
class ParkingRow : public InstancedMeshComponent
{
public:
    ParkingRow();
    static MeshLodData VehicleMesh();
};
