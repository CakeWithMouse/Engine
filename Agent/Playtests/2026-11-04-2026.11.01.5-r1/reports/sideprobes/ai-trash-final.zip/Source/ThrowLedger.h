#pragma once
#include <nlohmann/json.hpp>
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/ProjectObject.h>
ENGINE_OBJECT("ThrowLedger")
class ThrowLedger
{
public:
    ThrowLedger() = default;
    uint32_t throws = 0;
    uint32_t hits = 0;
};

template<> struct ProjectObjectAdapter<ThrowLedger>
{
    static std::unique_ptr<ThrowLedger> Create() { return std::make_unique<ThrowLedger>(); }
    static void Tick(ThrowLedger&, float) {}
    static std::string Save(const ThrowLedger& value)
    {
        return nlohmann::json{{"version",1},{"throws",value.throws},{"hits",value.hits}}.dump();
    }
    static void Load(ThrowLedger& value, const std::string& text)
    {
        if (text.empty()) return;
        const auto data = nlohmann::json::parse(text);
        if (data.at("version").get<int>() != 1) throw std::runtime_error("Unsupported ThrowLedger schema");
        value.throws = data.at("throws").get<uint32_t>();
        value.hits = data.at("hits").get<uint32_t>();
    }
};
