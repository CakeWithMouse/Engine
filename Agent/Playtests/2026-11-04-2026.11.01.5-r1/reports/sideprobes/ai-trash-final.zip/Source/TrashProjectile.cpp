#include "TrashProjectile.h"

#include "BucketParts.h"
#include "ProjectGame.h"

#include <Engine/Render/MeshPrimitives.h>
#include <Engine/Scene/Scene.h>
#include <Engine/Scene/Trace.h>
#include <algorithm>
#include <cmath>

TrashProjectile::TrashProjectile()
{
    SetPrimitive(MeshPrimitives::Cube());
    SetScale({0.42f, 0.42f, 0.42f});
    SetColor({0.95f, 0.48f, 0.16f, 1.0f});
}

void TrashProjectile::Configure(Kind kind, uint64_t targetId, const glm::vec3& start, float duration)
{
    targetId_ = targetId;
    start_ = start;
    duration_ = (std::max)(duration, 0.1f);
    elapsed_ = 0.0f;
    resolved_ = false;

    switch (kind) {
    case Kind::Box:
        SetPrimitive(MeshPrimitives::Cube());
        SetColor({0.94f, 0.32f, 0.16f, 1.0f});
        SetScale({0.46f, 0.34f, 0.42f});
        break;
    case Kind::Can:
        SetPrimitive(MeshPrimitives::Cylinder(0.5f, 1.0f, 16));
        SetColor({0.98f, 0.73f, 0.2f, 1.0f});
        SetScale({0.36f, 0.5f, 0.36f});
        break;
    case Kind::CrumpledPaper:
        SetPrimitive(MeshPrimitives::Sphere(0.5f, 12, 8));
        SetColor({0.82f, 0.88f, 0.94f, 1.0f});
        SetScale({0.38f, 0.32f, 0.36f});
        break;
    }
    SetPosition(start_);
}

void TrashProjectile::Tick(float deltaTime)
{
    MeshComponent::Tick(deltaTime);
    if (resolved_ || deltaTime <= 0.0f)
        return;

    const glm::vec3 previous = GetLocalPosition();
    elapsed_ = (std::min)(elapsed_ + deltaTime, duration_);
    const float t = elapsed_ / duration_;
    const glm::vec3 next{start_.x, start_.y + (0.2f - start_.y) * t + 15.0f * t * (1.0f - t),
                         start_.z + 10.2f * t};
    const glm::vec3 delta = next - previous;
    const float distance = glm::length(delta);
    if (distance > 0.0001f) {
        Trace::Ray ray{previous, delta, distance};
        Trace::Query query;
        query.geometry = Trace::Geometry::Exact;
        query.maxDistance = distance;
        auto* scene = GetScene();
        for (const auto& entry : scene->GetComponents()) {
            if (dynamic_cast<const TrashProjectile*>(entry.second.get()))
                query.ignore.push_back(entry.second->GetComponentId());
        }
        const auto hit = scene->Raycast(ray, query);
        if (hit) {
            if (hit.hit->componentId == targetId_) {
                if (auto* game = dynamic_cast<ProjectGame*>(GetGame()))
                    game->RegisterHit();
            } else if (auto* game = dynamic_cast<ProjectGame*>(GetGame())) {
                const auto* hitComponent = scene->FindComponent(hit.hit->componentId);
                game->RegisterMiss(dynamic_cast<const BucketWall*>(hitComponent)
                    ? "The trash hit the bucket wall."
                    : "The trash hit an obstacle.");
            }
            resolved_ = true;
            return;
        }
    }

    SetPosition(next);
    if (t >= 1.0f) {
        resolved_ = true;
        if (auto* game = dynamic_cast<ProjectGame*>(GetGame()))
            game->RegisterMiss("The trash missed the bucket.");
    }
}
