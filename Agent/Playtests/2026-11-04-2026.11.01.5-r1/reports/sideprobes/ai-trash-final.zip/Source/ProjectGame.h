#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/InputDevice/InputActions.h>
#include <Engine/Components/Character.h>
#include <string>

ENGINE_GAME("ProjectGame")
class ProjectGame : public Game
{
public:
    void AfterInitialize() override;
    void PreUpdate(float deltaTime) override;
    void TickComponents(float deltaTime) override;
    void ThrowTrash();
    void RegisterHit();
    void RegisterMiss(const std::string& reason);

private:
    void UpdateHud();
    uint32_t throws_ = 0;
    uint32_t hits_ = 0;
    bool hudBound_ = false;
    Input::Connection throwConnection_;
    Input::Scope throwScope_;
};
