#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/MeshComponent.h>

class TrashProjectile : public MeshComponent
{
public:
    enum class Kind { Box, Can, CrumpledPaper };

    TrashProjectile();
    void Configure(Kind kind, uint64_t targetId, const glm::vec3& start, float duration);
    void Tick(float deltaTime) override;

private:
    uint64_t targetId_ = 0;
    glm::vec3 start_{0.0f, 0.7f, -5.0f};
    float elapsed_ = 0.0f;
    float duration_ = 1.6f;
    bool resolved_ = false;
};

ENGINE_COMPONENT("Thrown trash", "Trash.Projectile")
class TrashProjectileComponent : public TrashProjectile
{
public:
    TrashProjectileComponent() = default;
};
