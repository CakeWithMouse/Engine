#include "ProjectGame.h"
#include "BucketParts.h"
#include "ThrowLedger.h"
#include "TrashProjectile.h"

#include <Engine/Render/MeshPrimitives.h>
#include <Engine/Scene/Scene.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/Components/Light/DirectionalLightComponent.h>
#include <stdexcept>
#include <string>

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    SetSimulationTimeScale(1.0f);

    auto& scene = GetScene();
    bool hasSun = false;
    bool hasPlayer = false;
    for (const auto& entry : scene.GetComponents()) {
        hasSun |= dynamic_cast<DirectionalLightComponent*>(entry.second.get()) != nullptr;
        if (const auto* character = dynamic_cast<Character*>(entry.second.get()))
            hasPlayer |= character->playerControlled;
    }
    if (!hasSun) {
        std::unique_ptr<GameComponent> sun = std::make_unique<DirectionalLightComponent>();
        const auto added = scene.AddComponent("Trash sun", sun, "Light.Directional");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the trash scene sun");
    }

    if (!hasPlayer) {
        auto view = std::make_unique<SceneCamera>();
        view->SetPosition({9.0f, 7.0f, -11.0f});
        view->SetRotation({-23.0f, 140.0f, 0.0f});
        view->orthographic = false;
        view->fov = 58.0f;
        view->farClip = 250.0f;
        std::unique_ptr<GameComponent> component = std::move(view);
        const auto added = scene.AddComponent("Trash view", component, "Gameplay.Camera");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the trash game camera");

        auto rig = std::make_unique<PlayerCharacter>();
        rig->SetPosition({0.0f, -100.0f, 0.0f});
        rig->SetScale({0.1f, 0.1f, 0.1f});
        rig->SetPlayerControlled(true);
        rig->standardControl = false;
        rig->camera = added.id;
        std::unique_ptr<GameComponent> player = std::move(rig);
        const auto playerAdded = scene.AddComponent("Trash camera rig", player, "Gameplay.Player");
        if (playerAdded.result != SceneResult::Ok && playerAdded.result != SceneResult::Deferred)
            throw std::runtime_error("Cannot add the trash camera rig");
    }

    Input::Binding binding;
    binding.action = "Trash.Throw";
    binding.context = Input::Context::Game;
    binding.chord = {Keys::Space};
    GetInput().Bind(binding);
    binding.chord = {Keys::T};
    GetInput().Bind(binding);
    throwConnection_ = GetInput().Subscribe(throwScope_, Input::Context::Game, "Trash.Throw",
        Input::Phase::Pressed, [this](const Input::Event& event) {
            if (!event.cancelled) ThrowTrash();
        });
}

void ProjectGame::PreUpdate(float deltaTime)
{
    Game::PreUpdate(deltaTime);
    if (!hudBound_ && GetProjectHud()) {
        GetProjectHud()->BindClick("throw", [this] { ThrowTrash(); });
        hudBound_ = true;
    }
}

void ProjectGame::ThrowTrash()
{
    auto* target = GetScene().FindComponentByName("Bucket base");
    if (!target) {
        RegisterMiss("Bucket target is missing.");
        return;
    }

    const auto kind = static_cast<TrashProjectile::Kind>(throws_ % 3);
    const char* names[] = {"Cardboard box", "Soda can", "Crumpled paper"};
    std::unique_ptr<GameComponent> projectile = std::make_unique<TrashProjectileComponent>();
    auto* trash = static_cast<TrashProjectile*>(projectile.get());
    trash->Configure(kind, target->GetComponentId(), {0.0f, 0.7f, -5.0f}, 1.6f);
    const std::string name = std::string(names[throws_ % 3]) + " " + std::to_string(throws_ + 1);
    const auto added = GetScene().AddComponent(name, projectile, "Trash.Projectile");
    if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred) {
        RegisterMiss("Could not launch trash.");
        return;
    }
    ++throws_;
    if (auto* ledger = dynamic_cast<ProjectObjectComponent<ThrowLedger>*>(GetScene().FindComponentByName("Throw ledger")))
        ++ledger->Value().throws;
    if (GetProjectHud()) {
        GetProjectHud()->SetLabelText("status", std::string("Flying: ") + names[(throws_ - 1) % 3]);
        UpdateHud();
    }
}

void ProjectGame::RegisterHit()
{
    ++hits_;
    if (auto* ledger = dynamic_cast<ProjectObjectComponent<ThrowLedger>*>(GetScene().FindComponentByName("Throw ledger")))
        ++ledger->Value().hits;
    if (GetProjectHud()) {
        GetProjectHud()->SetLabelText("status", "Hit! In the bucket.");
        UpdateHud();
    }
}

void ProjectGame::RegisterMiss(const std::string& reason)
{
    if (GetProjectHud())
        GetProjectHud()->SetLabelText("status", reason);
}

void ProjectGame::UpdateHud()
{
    if (GetProjectHud())
        GetProjectHud()->SetLabelText("score", std::string("Hits: ") + std::to_string(hits_) + " / Throws: " + std::to_string(throws_));
}

void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }
