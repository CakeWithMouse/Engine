#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>

ENGINE_COMPONENT("City building", "CalmCity.Building")
class CityBuilding : public CubeComponent
{
public:
    CityBuilding();
};
