#include "CityBuilding.h"

CityBuilding::CityBuilding()
{
    SetColor({0.35f, 0.62f, 0.74f, 1.0f});
}
