#include "CarMover.h"

#include <algorithm>

CarMover::CarMover()
{
    SetColor({0.92f, 0.23f, 0.12f, 1.0f});
}

void CarMover::Tick(float deltaTime)
{
    CubeComponent::Tick(deltaTime);
    if (!moving || deltaTime <= 0.0f)
        return;

    auto position = GetLocalPosition();
    const float limit = 5.6f;
    position.x += (goingRight ? 1.0f : -1.0f) * speed * deltaTime;
    if (position.x >= limit) {
        position.x = limit;
        goingRight = false;
    } else if (position.x <= -limit) {
        position.x = -limit;
        goingRight = true;
    }
    SetPosition(position);
}
