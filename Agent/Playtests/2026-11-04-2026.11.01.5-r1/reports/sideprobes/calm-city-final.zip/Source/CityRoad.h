#pragma once

#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/SpecificComponents/CubeComponent.h>

ENGINE_COMPONENT("Street", "CalmCity.Street")
class CityRoad : public CubeComponent
{
public:
    CityRoad();
};
