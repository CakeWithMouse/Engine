#include "CityRoad.h"

CityRoad::CityRoad()
{
    SetColor({0.15f, 0.18f, 0.21f, 1.0f});
}
