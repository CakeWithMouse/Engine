#pragma once
#include <string>
namespace ReferenceExamples { std::string ReadGameLine(); }
