#include "ProjectGame.h"
#include "RotatingCube.h"
#include "ReferenceExamples.h"
#include <Engine/Runtime/ModuleVfs.h>
#include <Engine/Components/Character.h>
#include <stdexcept>
#include <iostream>

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    // One full turn in four real seconds, independent of the frame rate.
    SetSimulationTimeScale(1.0f);
    const auto resolved = EngineModuleVfs::Resolve("/Game/Config/message.txt");
    const auto marker = ReferenceExamples::ReadGameLine();
    std::cout << "Host VFS resolve: " << (!resolved.empty()) << " read=" << marker << std::endl;
    auto& scene = GetScene();
    auto view = std::make_unique<SceneCamera>();
    view->SetPosition({2.0f, 1.0f, -8.0f});
    view->SetRotation({0.0f, 180.0f, 0.0f});
    std::unique_ptr<GameComponent> viewComponent = std::move(view);
    const auto cameraAdded = scene.AddComponent("Trace screen camera", viewComponent, "Gameplay.Camera");
    if (cameraAdded.result != SceneResult::Ok && cameraAdded.result != SceneResult::Deferred)
        throw std::runtime_error("Cannot add TraceScreen camera");
    auto player = std::make_unique<PlayerCharacter>();
    player->SetPosition({0.0f, -100.0f, 0.0f});
    player->standardControl = false;
    player->camera = cameraAdded.id;
    std::unique_ptr<GameComponent> playerComponent = std::move(player);
    const auto playerAdded = scene.AddComponent("Trace screen player", playerComponent, "Gameplay.Player");
    if (playerAdded.result != SceneResult::Ok && playerAdded.result != SceneResult::Deferred)
        throw std::runtime_error("Cannot add TraceScreen player");
    InitializeGameplay();
    const auto screenRay = ScreenPointToRay(Trace::ViewportPoint::Pixel(640, 360), 100.0f);
    const auto centerTrace = RaycastScreen(Trace::ViewportPoint::Pixel(640, 360));
    const auto fractionalTrace = RaycastScreen(Trace::ViewportPoint::Logical(640.25f, 359.75f, 1.0f));
    std::cout << "TraceScreen center ray=" << Trace::StatusName(screenRay.status)
              << " hit=" << Trace::StatusName(centerTrace.status)
              << " fractional=" << Trace::StatusName(fractionalTrace.status)
              << " triangles=" << centerTrace.statistics.triangles << std::endl;
    // A saved RotatingCube already supplies the example after loading/Play.
    for (const auto& entry : scene.GetComponents())
        if (dynamic_cast<RotatingCube*>(entry.second.get())) return;
    std::unique_ptr<GameComponent> cube = std::make_unique<RotatingCube>();
    cube->SetPosition({2.0f, 1.0f, 0.0f});
    std::string name = "RotatingCube";
    for (unsigned suffix = 2; scene.FindComponentByName(name); ++suffix)
        name = "RotatingCube" + std::to_string(suffix);
    const auto added = scene.AddComponent(name, cube, "RotatingCube");
    if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
        throw std::runtime_error("Cannot add the starter RotatingCube");
}

void ProjectGame::PreUpdate(float deltaTime) { Game::PreUpdate(deltaTime); }
void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }

