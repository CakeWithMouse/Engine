#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include "ProjectComponent.h"
ENGINE_COMPONENT("FeatureProbeComponent")
class FeatureProbeComponent : public ProjectComponent
{
public:
    FeatureProbeComponent() = default;
    void BeginPlay() override;
    void Tick(float deltaTime) override;
};
