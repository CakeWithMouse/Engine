#include "FeatureProbeComponent.h"
void FeatureProbeComponent::BeginPlay() { ProjectComponent::BeginPlay(); }
void FeatureProbeComponent::Tick(float deltaTime) { ProjectComponent::Tick(deltaTime); }
