#include "ProjectGame.h"
#include "CarMover.h"
#include <Engine/Components/Character.h>
#include <Engine/Components/Light/DirectionalLightComponent.h>
#include <stdexcept>

void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    // One full turn in four real seconds, independent of the frame rate.
    SetSimulationTimeScale(1.0f);
    auto& scene = GetScene();
    // An overview camera and a sun make the existing city readable at first Play.
    std::unique_ptr<GameComponent> camera = std::make_unique<SceneCamera>();
    camera->SetPosition({14.0f, 12.0f, 18.0f});
    camera->SetRotation({-28.0f, 38.0f, 0.0f});
    const auto cameraResult = scene.AddComponent("City overview", camera);
    if (cameraResult.result != SceneResult::Ok) throw std::runtime_error("Cannot create city camera");
    auto player = std::make_unique<Character>();
    player->SetPlayerControlled(true);
    player->standardControl = false;
    player->camera = cameraResult.id;
    std::unique_ptr<GameComponent> playerComponent = std::move(player);
    if (scene.AddComponent("City viewer", playerComponent).result != SceneResult::Ok)
        throw std::runtime_error("Cannot create city viewer");
    bool hasSun = false;
    for (const auto& entry : scene.GetComponents())
        if (dynamic_cast<DirectionalLightComponent*>(entry.second.get())) hasSun = true;
    if (!hasSun) {
        std::unique_ptr<GameComponent> sun = std::make_unique<DirectionalLightComponent>();
        sun->SetRotation({-50.0f, -30.0f, 0.0f});
        if (scene.AddComponent("City sun", sun, "Light.Directional").result != SceneResult::Ok)
            throw std::runtime_error("Cannot create city sun");
    }
    // A saved CarMover already supplies the example after loading/Play.
    for (const auto& entry : scene.GetComponents())
        if (dynamic_cast<CarMover*>(entry.second.get())) return;
    std::unique_ptr<GameComponent> cube = std::make_unique<CarMover>();
    cube->SetPosition({-5.6f, 0.55f, 0.0f});
    cube->SetScale({1.35f, 0.35f, 0.72f});
    std::string name = "Car mover";
    for (unsigned suffix = 2; scene.FindComponentByName(name); ++suffix)
        name = "Car mover " + std::to_string(suffix);
    const auto added = scene.AddComponent(name, cube, "CalmCity.CarMover");
    if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
        throw std::runtime_error("Cannot add the starter car");
}

void ProjectGame::PreUpdate(float deltaTime) { Game::PreUpdate(deltaTime); }
void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }
