#include "ProjectGame.h"
#include "CityEconomySubsystem.h"
#include <Engine/MainGame/Player.h>
#include <Engine/Scene/SceneDocument.h>
#include <Engine/Runtime/ModuleVfs.h>
#include <Engine/Scene/SceneAssets.h>
#include <cstdlib>
#include <stdexcept>
#include <string>
#include <fstream>
#include <filesystem>
#include <Windows.h>
#include <iterator>
namespace ReferenceExamples { std::string ReadGameLine(); }

namespace
{
    void RunSessionProbe()
    {
        const char* enabled = std::getenv("CURIOUS_CITY_SESSION_PROBE");
        if (!enabled || !*enabled || *enabled == '0') return;
        GameSession session;
        std::string error;
        if (!session.Initialize(error)) throw std::runtime_error("Session probe initialize: " + error);
        auto* original = session.GetSubsystem<CityEconomySubsystem>();
        if (!original) throw std::runtime_error("Session probe subsystem missing");
        int firstBalance = 0;
        {
            Game first;
            first.AttachSession(session);
            first.InitializeGameplay();
            first.StepProjectSimulation(1.0f);
            firstBalance = original->balance;
            first.CloseGameplayScene();
        }
        if (!session.IsRunning() || session.GetScene() || session.GetSubsystem<CityEconomySubsystem>() != original)
            throw std::runtime_error("Session probe did not survive first scene");
        {
            Game second;
            second.AttachSession(session);
            second.InitializeGameplay();
            auto* resumed = second.GetSubsystem<CityEconomySubsystem>();
            if (resumed != original || resumed->balance != firstBalance || resumed->scenesOpened != 2)
                throw std::runtime_error("Session probe state was not reused");
            second.StepProjectSimulation(1.0f);
            if (resumed->balance != firstBalance + 30)
                throw std::runtime_error("Session probe income did not continue");
            resumed->RecordEvent("session_reused", "same subsystem; scenes=2");
            second.CloseGameplayScene();
        }
        session.Stop();
    }
}

namespace
{
    void RunVfsProbe()
    {
        const char* enabled = std::getenv("CURIOUS_CITY_VFS_PROBE");
        if (!enabled || !*enabled || *enabled == '0') return;
        const auto line = ReferenceExamples::ReadGameLine();
        wchar_t path[32768]{};
        const DWORD length = GetEnvironmentVariableW(L"CURIOUS_CITY_LOG", path, static_cast<DWORD>(std::size(path)));
        if (!length || length >= std::size(path)) return;
        std::ofstream file(std::filesystem::path(path), std::ios::app);
        if (file) file << "event=vfs_read detail=" << line << '\n';
    }
}
namespace
{
    void RunSceneDocumentProbe()
    {
        const char* enabled = std::getenv("CURIOUS_CITY_SCENE_DOC_PROBE");
        if (!enabled || !*enabled || *enabled == '0') return;
        const auto sourceText = EngineModuleVfs::Resolve("/Game/Scenes/PropertiesProbe.scene.json");
        if (sourceText.empty()) throw std::runtime_error("Scene document probe source is unavailable");
        const auto source = std::filesystem::u8path(sourceText);
        const auto savedAs = source.parent_path() / L"PropertiesProbe.SaveAs.scene.json";
        const auto original = SceneDocument::Read(source);
        SceneDocument::Write(savedAs, original);
        const auto reopened = SceneDocument::Read(savedAs);
        if (reopened.components.size() != original.components.size() || reopened.documentVersion != original.documentVersion)
            throw std::runtime_error("Scene Save As / reopen changed the document shape");
        bool foundHouse = false, foundRules = false;
        for (const auto& item : reopened.components)
        {
            if (item.name == "PersistedHouse") foundHouse = item.projectData.find("houseHeight") != std::string::npos;
            if (item.name == "Rules") foundRules = item.projectData.find("maxHouses") != std::string::npos;
        }
        if (!foundHouse || !foundRules) throw std::runtime_error("Scene Save As / reopen lost custom data");
        wchar_t logPath[32768]{};
        const DWORD length = GetEnvironmentVariableW(L"CURIOUS_CITY_LOG", logPath, static_cast<DWORD>(std::size(logPath)));
        if (length && length < std::size(logPath))
        {
            std::ofstream file(std::filesystem::path(logPath), std::ios::app);
            if (file) file << "event=scene_document_saveas_reopen objects=" << reopened.components.size() << '\n';
        }
    }
}
namespace
{
    void RunAssetPathProbe()
    {
        const char* enabled = std::getenv("CURIOUS_CITY_ASSET_PROBE");
        if (!enabled || !*enabled || *enabled == '0') return;
        auto log = [](const std::string& message) {
            wchar_t path[32768]{};
            const DWORD length = GetEnvironmentVariableW(L"CURIOUS_CITY_LOG", path, static_cast<DWORD>(std::size(path)));
            if (!length || length >= std::size(path)) return;
            std::ofstream file(std::filesystem::path(path), std::ios::app);
            if (file) file << message << '\n';
        };
        try
        {
            const auto contentText = EngineModuleVfs::Resolve("/Game");
            if (contentText.empty()) throw std::runtime_error("Resolve /Game returned an empty path");
            const auto content = std::filesystem::u8path(contentText);
            const auto source = content / "ImportSource/CesiumMan.glb";
            if (!std::filesystem::is_regular_file(source)) throw std::runtime_error("GLB source file is missing");
            const auto model = SceneAssets::Import(content, source, SceneAssets::Model);
            if (!SceneAssets::ValidPath(model)) throw std::runtime_error("Import returned a non-portable model path");
            auto component = SceneAssets::CreateModel(model, false);
            if (!component) throw std::runtime_error("Import did not produce a model component");
            log("event=asset_import_valid model=" + model);
        }
        catch (const std::exception& error)
        {
            log(std::string("event=asset_import_failed detail=") + error.what());
            throw;
        }
    }
}
void ProjectGame::AfterInitialize()
{
    Game::AfterInitialize();
    SetSimulationTimeScale(1.0f);
    if (auto* camera = GetPlayer())
    {
        camera->SetPosition({0.0f, 3.5f, -9.0f});
        camera->SetRotate(1.5707963f, -0.38f);
    }
    RunSessionProbe();
    RunVfsProbe();
    RunSceneDocumentProbe();
    RunAssetPathProbe();
}

void ProjectGame::PreUpdate(float deltaTime) { Game::PreUpdate(deltaTime); }
void ProjectGame::TickComponents(float deltaTime) { Game::TickComponents(deltaTime); }