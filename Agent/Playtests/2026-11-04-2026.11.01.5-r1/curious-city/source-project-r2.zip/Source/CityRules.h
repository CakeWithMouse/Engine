#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/ProjectObject.h>
#include <nlohmann/json.hpp>
#include <memory>
#include <stdexcept>
#include <string>

ENGINE_OBJECT("Городские правила", "CuriousCity.Rules")
class CityRules
{
public:
    int maxHouses = 8;
    bool logged = false;
};

void LogCityRules(int maxHouses);

template<> struct ProjectObjectAdapter<CityRules>
{
    static std::unique_ptr<CityRules> Create() { return std::make_unique<CityRules>(); }
    static void Tick(CityRules& rules, float)
    {
        if (!rules.logged) { LogCityRules(rules.maxHouses); rules.logged = true; }
    }
    static std::string Save(const CityRules& rules)
    {
        return nlohmann::json{{"version", 1}, {"maxHouses", rules.maxHouses}}.dump();
    }
    static void Load(CityRules& rules, const std::string& text)
    {
        if (text.empty()) return;
        const auto data = nlohmann::json::parse(text);
        if (data.at("version") != 1) throw std::runtime_error("Unsupported CityRules schema");
        const int value = data.at("maxHouses").get<int>();
        if (value < 1 || value > 30) throw std::runtime_error("CityRules maxHouses out of range");
        rules.maxHouses = value;
    }
};