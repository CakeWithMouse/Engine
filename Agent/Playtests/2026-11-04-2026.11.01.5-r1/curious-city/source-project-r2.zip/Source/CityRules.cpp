#include "CityRules.h"
#include <Windows.h>
#include <filesystem>
#include <fstream>
#include <string>

void LogCityRules(int maxHouses)
{
    wchar_t path[32768]{};
    const DWORD length = GetEnvironmentVariableW(L"CURIOUS_CITY_LOG", path, static_cast<DWORD>(std::size(path)));
    if (!length || length >= std::size(path)) return;
    std::ofstream file(std::filesystem::path(path), std::ios::app);
    if (file) file << "event=project_object_tick maxHouses=" << maxHouses << '\n';
}