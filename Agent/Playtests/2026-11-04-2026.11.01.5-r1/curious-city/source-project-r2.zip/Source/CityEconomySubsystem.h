#pragma once
#include <Engine/MainGame/GameSubsystem.h>
#include <string>

class UIComponent;
ENGINE_SUBSYSTEM()
class CityEconomySubsystem final : public GameSubsystem
{
public:
    CityEconomySubsystem();
    void OnSceneReady(Scene& scene) override;
    void OnSceneClosing(Scene&) override;
    void Tick(float deltaTime) override;
    void RecordEvent(const char* event, const std::string& detail = {});
    void SetStatus(const std::string& text);
    void AttachHud(UIComponent* component);

    int balance = 500;
    int houses = 0;
    int scenesOpened = 0;
    double elapsed = 0.0;
private:
    void UpdateHud();
    double incomeClock = 0.0;
    bool started = false;
    UIComponent* hud = nullptr; // borrowed from the current Scene
};