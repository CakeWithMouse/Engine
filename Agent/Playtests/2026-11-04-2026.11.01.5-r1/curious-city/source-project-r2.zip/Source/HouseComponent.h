#pragma once
#include <Engine/Components/ComponentAnnotations.h>
#include <Engine/Components/GameComponents.h>
#include <Engine/Components/PropertyMacros.h>

ENGINE_COMPONENT("Дом", "CuriousCity.House")
class HouseComponent final : public GameComponent
{
public:
    ENGINE_GENERATED_PROPERTIES(GameComponent)
    HouseComponent();
    void BeginPlay() override;
    void SetHouseHeight(float value);
    void OnPropertiesChanged();
private:
    ENGINE_PROPERTY("Высота", 0.75, 2.5)
    float houseHeight = 1.0f;
};