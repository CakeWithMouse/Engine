#include "CityEconomySubsystem.h"
#include "CityInteractionComponent.h"
#include "HouseComponent.h"
#include <Engine/Components/GameComponents.h>
#include <Engine/Components/Character.h>
#include <Engine/Components/SpecificComponents/UIComponent.h>
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/Scene/Scene.h>
#include <Windows.h>
#include <filesystem>
#include <algorithm>
#include <fstream>
#include <iomanip>
#include <string>
#include <sstream>

namespace
{
    void WriteLog(const std::string& line)
    {
        wchar_t logPath[32768]{};
        const DWORD length = GetEnvironmentVariableW(L"CURIOUS_CITY_LOG", logPath, static_cast<DWORD>(std::size(logPath)));
        if (length == 0 || length >= std::size(logPath)) return;
        std::ofstream file(std::filesystem::path(logPath), std::ios::app);
        if (file) file << line << '\n';
    }
}

CityEconomySubsystem::CityEconomySubsystem() { bTickEnabled = true; }

void CityEconomySubsystem::OnSceneReady(Scene& scene)
{
    ++scenesOpened;
    if (const auto* player = dynamic_cast<const Character*>(scene.FindComponentByName("ProbePlayer")))
        RecordEvent("character_probe_loaded", "player=" + std::to_string(player->playerControlled) + " camera=" + std::to_string(player->camera) + " plane=" + std::to_string(player->cameraSettings.viewPlane));
    if (const auto* camera = dynamic_cast<const SceneCamera*>(scene.FindComponentByName("TopDownCamera")))
        RecordEvent("orthographic_camera_loaded", "orthographic=" + std::to_string(camera->orthographic) + " plane=" + std::to_string(camera->viewPlane) + " height=" + std::to_string(camera->orthoHeight));
    if (auto* cube = scene.FindComponentByName("Cube"))
    {
        const auto removed = scene.RemoveComponent(cube->GetComponentId());
        RecordEvent(removed == SceneResult::Ok ? "template_cube_removed" : "template_cube_remove_failed");
    }
    if (!started)
    {
        balance = 500;
        houses = 3;
        elapsed = 0.0;
        incomeClock = 0.0;
        started = true;
        constexpr int houseCost = 100;
        balance -= houses * houseCost;
    }
    const glm::vec4 colors[] = {
        {0.78f, 0.34f, 0.22f, 1.0f},
        {0.82f, 0.67f, 0.32f, 1.0f},
        {0.34f, 0.57f, 0.72f, 1.0f}
    };
    for (int i = 0; i < houses; ++i)
    {
        auto house = std::make_unique<HouseComponent>();
        const float height = 1.0f + 0.35f * static_cast<float>(i);
        house->SetHouseHeight(height);
        house->SetPosition({static_cast<float>((i - 1) * 2.5f), -0.5f + height * 0.5f, -2.0f});
        house->SetColor(colors[i % 3]);
        const std::string name = "House_" + std::to_string(i + 1);
        std::unique_ptr<GameComponent> component = std::move(house);
        const auto added = scene.AddComponent(name, component, "CuriousCity.House");
        if (added.result != SceneResult::Ok && added.result != SceneResult::Deferred)
        {
            RecordEvent("spawn_failed", name);
            continue;
        }
        if (!component) RecordEvent("house_spawned", name);
    }
    RecordEvent("city_hud_configured");
    auto interaction = std::make_unique<CityInteractionComponent>();
    std::unique_ptr<GameComponent> inputComponent = std::move(interaction);
    scene.AddComponent("CityInput", inputComponent, "CuriousCity.Interaction");
    UpdateHud();
    RecordEvent("city_started");
}

void CityEconomySubsystem::OnSceneClosing(Scene&)
{
    if (hud) hud->UnbindClick("incomeToggle");
    hud = nullptr;
}

void CityEconomySubsystem::Tick(float deltaTime)
{
    if (deltaTime <= 0.0f) return;
    elapsed += deltaTime;
    incomeClock += deltaTime;
    while (incomeClock >= 1.0)
    {
        incomeClock -= 1.0;
        balance += houses * 10;
        UpdateHud();
        RecordEvent("income");
    }
}

void CityEconomySubsystem::UpdateHud()
{
    if (!hud) return;
    hud->SetLabelText("balance", "Balance: " + std::to_string(balance));
    hud->SetLabelText("status", "Income: " + std::to_string(houses * 10) + " / second");
    hud->SetBarFill("balanceBar", std::clamp(static_cast<float>(balance) / 800.0f, 0.0f, 1.0f));
}

void CityEconomySubsystem::AttachHud(UIComponent* component)
{
    hud = component;
    if (!hud) { RecordEvent("hud_unavailable"); return; }
    hud->BindClick("incomeToggle", [this]() {
        bTickEnabled = !bTickEnabled;
        SetStatus(bTickEnabled ? "Income resumed" : "Income paused");
        if (auto* button = hud->Find<UIButton>("incomeToggle"))
            button->SetText(bTickEnabled ? "Pause income" : "Resume income");
        RecordEvent(bTickEnabled ? "income_resumed" : "income_paused");
    });
    UpdateHud();
    RecordEvent("hud_attached");
}
void CityEconomySubsystem::SetStatus(const std::string& text)
{
    if (hud) hud->SetLabelText("status", text);
}

void CityEconomySubsystem::RecordEvent(const char* event, const std::string& detail)
{
    std::ostringstream line;
    line << std::fixed << std::setprecision(1)
         << "event=" << event << " elapsed=" << elapsed << "s balance=" << balance
         << " houses=" << houses;
    if (!detail.empty()) line << " detail=" << detail;
    WriteLog(line.str());
}