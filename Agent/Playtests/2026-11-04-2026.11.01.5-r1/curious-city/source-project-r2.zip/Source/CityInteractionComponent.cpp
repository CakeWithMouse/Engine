#include "CityInteractionComponent.h"
#include "CityEconomySubsystem.h"
#include "HouseComponent.h"
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <cstdlib>
#include <sstream>
#include <string>

void CityInteractionComponent::BeginPlay()
{
    GameComponent::BeginPlay();
    auto* game = GetGame();
    if (!game) return;
    if (auto* economy = game->GetSubsystem<CityEconomySubsystem>()) economy->AttachHud(game->GetProjectHud());
    if (const char* enabled = std::getenv("CURIOUS_CITY_DEBUG_TRACE_PROBE"); enabled && *enabled && *enabled != '0')
    {
        const Trace::Ray probeRay{{0.0f, 10.0f, -2.0f}, {0.0f, -1.0f, 0.0f}, 30.0f};
        auto* scene = GetScene();
        const auto result = scene->Raycast(probeRay);
        game->DebugDrawTrace(probeRay, result, 10.0f);
        const auto& stats = scene->GetTraceStatistics();
        std::ostringstream detail;
        detail << "status=" << Trace::StatusName(result.status)
               << " lines=" << game->GetDebugTraceLineCount()
               << " queries=" << stats.queries << " bounds=" << stats.bounds
               << " triangles=" << stats.triangles << " unsupported=" << stats.unsupported
               << " microseconds=" << stats.microseconds;
        if (result.hit) detail << " hit=" << result.hit->componentId << " normal_y=" << result.hit->normal.y;
        if (auto* subsystem = game->GetSubsystem<CityEconomySubsystem>())
            subsystem->RecordEvent("trace_debug_runtime_state", detail.str());
        game->ClearDebugTraces();
        if (auto* subsystem = game->GetSubsystem<CityEconomySubsystem>())
            subsystem->RecordEvent("trace_debug_cleared", "lines=" + std::to_string(game->GetDebugTraceLineCount()));
    }
    Input::Binding binding;
    binding.action = "CuriousCity.SelectHouse";
    binding.context = Input::Context::Game;
    binding.chord = {Keys::LeftButton};
    game->GetInput().Bind(binding);
    selectionConnection_ = game->GetInput().Subscribe(selectionScope_, Input::Context::Game,
        "CuriousCity.SelectHouse", Input::Phase::Pressed, [this](const Input::Event& event) {
            if (event.cancelled || !GetGame()) return;
            auto* activeGame = GetGame();
            const auto cursor = activeGame->GetInput().GetCursorPosition();
            if (!cursor.valid) return;
            const auto ray = activeGame->ScreenPointToRay({cursor.x, cursor.y});
            const auto result = activeGame->RaycastCursor();
            if (ray) activeGame->DebugDrawTrace(ray.ray, result, 1.5f);
            if (ray && result){
                Trace::Query filteredQuery;
                filteredQuery.channels = 2u;
                const auto filtered = GetScene()->Raycast(ray.ray, filteredQuery);
                if (auto* subsystem = activeGame->GetSubsystem<CityEconomySubsystem>())
                    subsystem->RecordEvent("trace_channel_filter", Trace::StatusName(filtered.status));
            }
            auto* subsystem = activeGame->GetSubsystem<CityEconomySubsystem>();
            if (!subsystem) return;
            const auto* hit = result.hit ? GetScene()->FindComponent(result.hit->componentId) : nullptr;
            if (const auto* house = dynamic_cast<const HouseComponent*>(hit))
            {
                subsystem->RecordEvent("house_selected", "House " + std::to_string(house->GetComponentId()));
                subsystem->SetStatus("Selected: house " + std::to_string(house->GetComponentId()));
            }
            else
                subsystem->RecordEvent("cursor_trace", Trace::StatusName(result.status));
        });
}
