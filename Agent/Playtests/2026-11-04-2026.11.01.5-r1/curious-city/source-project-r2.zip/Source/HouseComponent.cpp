#include "HouseComponent.h"
#include "CityEconomySubsystem.h"
#include <Engine/MainGame/BaseGameClass/Game.h>
#include <Engine/Render/MeshPrimitives.h>
#include <string>

HouseComponent::HouseComponent()
{
    SetPrimitive(MeshPrimitives::Cube());
    OnPropertiesChanged();
}

void HouseComponent::SetHouseHeight(float value)
{
    houseHeight = value;
    OnPropertiesChanged();
}

void HouseComponent::OnPropertiesChanged()
{
    SetScale({1.0f, houseHeight, 1.0f});
}

void HouseComponent::BeginPlay()
{
    GameComponent::BeginPlay();
    if (GetGame())
        if (auto* economy = GetGame()->GetSubsystem<CityEconomySubsystem>())
            economy->RecordEvent("house_property_loaded", std::to_string(houseHeight));
}